@include('includes.htmlhead')
<!--Header starting-->
@include('includes.header')
<!--Header ending-->
@include('includes.breadcrum')


<div class="post-section aboutus">
    <div class="container">
        <div class="sidebar-content ml-0 mr-0  mt-5 mb-5 ">
            <form action="/searchfaq" method="get">
                {{csrf_field()}}
                <div class="input-group">
                    <input type="text" required="required" class="form-control"
                           placeholder="Search for your question..."
                           name="search" @if(isset($_GET['search'])) value="{{$_GET['search']}}"
                           @endif aria-label="Search for...">
                    <span class="input-group-btn">
                    <button type="submit" class="btn btn-secondary btn-search" type="button">
                      <span class="fa fa-search"></span>
                    </button>
                  </span>
                </div>
            </form>
        </div>
        <div class="radom">
            <div class="row">
                @if(isset($serachfaq))
                    @if(count($serachfaq) > 0)
                        <div class="col-lg-12">

                            <h5>Search Results :</h5>
                        </div>
                        @foreach($serachfaq as $single )
                            <div class="col-md-6">
                                <a href="{{$single->slug}}" class="single_faq">
                                    <h5>
                                        {{$single->title}} </h5>
                                </a>
                            </div>
                        @endforeach

                    @else
                        <div class="col-lg-12">

                            <h5>No result Found </h5>
                        </div>

                    @endif
                @endif

            <!-- Heading Text  -->
                <div class="col-lg-12 ">
                    <div class="area-title pt-sm-5 pb-5">
                        <div class="content">
                            <h2 class="text-center  logo-green">Frequently Asked Question</h2>
                            <div class="separate text-black-50"></div>
                            <h3 class="text-center text-black-50">Do You Want to Know</h3>
                        </div>
                    </div>
                </div>
                @if(!empty($faqs))
                    @foreach($faqs as $single )

                        <div class="col-md-6">
                            <a href="{{$single->slug}}" class="single_faq">
                                <h5>
                                    {{$single->title}} </h5>
                            </a>
                        </div>
                    @endforeach
                    <div class=" ml-3 mt-5 mb-5 mr-5">
                        {{ $faqs->onEachSide(5)->links() }}
                    </div>
                @endif
            </div>
        </div>


    </div>
</div>

@include("includes.footer")