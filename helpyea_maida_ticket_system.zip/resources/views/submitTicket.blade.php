@include('includes.htmlhead')

@include('includes.header')

@include('includes.breadcrum')
<section class="white section pt-5 pb-5">
    <div class="container reply-form">
        <div class="col-md-8 offset-md-2">
            <form method="post" action="/addticket" autocomplete="off" enctype="multipart/form-data" class="add-new-ticket">
                {{ csrf_field() }}
                <h4>Submit a new Ticket</h4>
                <div class="form-group">
                    <label for="subject">Subject <span class="required-field">*</span></label>
                    <input class="form-control" type="text" name="subject" value="">
                </div>
                <div class="form-group">
                    <label class="d-block p-0 col-lg-12">Select Department </label>
                    <select class="form-control" name="department"  autocomplete="off">
                        @foreach($departments as $single)
                            <option value="{{$single->id}}"> {{$single->department_name}}</option>
                        @endforeach

                    </select>
                </div>
                <div class="form-group">
                    <label for="message">Provide description <span class="required-field">*</span></label>
                    <textarea class="form-control unsetheigth" name="message" rows="4" value=""></textarea>
                </div>
                <div class="form-group">
                    <label for="attachement">Attachment</label>
                    <div class="btn btn-attached">
                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                        <input name="attachment" type="file">
                        Add file .png/.jpg/.jpeg/.svg
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" class="button" value="Save">
                </div>
            </form>
        </div>

    </div>
    <div class="clearfix"></div>
</section>


@include("includes.footer")

