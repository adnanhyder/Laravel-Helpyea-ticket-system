@include('includes.htmlhead')

@include('includes.header')

@include('includes.breadcrum')
@include('includes.message')

<section class="white section pt-5 pb-5">
    <div class="container">

        <div class="list-replies">

            <h1><b>Ticket: </b>{{$tickets_subject}} <span class="float-right"><b>Assigned To: </b>  {{$tickets_assigned_user_name->name}} <b> Department: </b>   {{$ticket_department_name->department_name}}</span></h1>


            @foreach($data as $single)

                <div class="reply-block">
                    <div class="ticket-user">

                        <img id="1357" class="img-circle img-responsive" alt="Adnanhyder"
                             src="{{asset('img/user/').'/'.$single->submitted_userdata_picture}}">
                    </div>
                    <div class="ticket-msg">
                        <div class="ticket-user-det">
                            <b>{{$single->submitted_userdata_name}}</b> <span class="float-right">{{$single->created_at}}</span>
                        </div>
                        <p>{{$single->tickets_message}} </p>
                        @if($single->ticket_attachment != "")
                        <p>Attachment</p>
                        <p><img src="{{asset('img/tickets/').'/'.$single->ticket_attachment}}" class="d-block img-thumbnail"> </p>
                        @endif
                    </div>
                </div>

            @endforeach


            <div class="clearfix"></div>
        </div>
        <div class="list-replies reply-form">
            <form method="post" action="/addticket" autocomplete="off" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="id" value="{{base64_encode($id)}}">
                <input type="hidden" name="tickets_assigned_user" value="{{base64_encode($tickets_assigned_user)}}">
                <div class="form-group">
                    <label for="message">Provide description <span class="required-field">*</span></label>
                    <textarea class="form-control unsetheigth" rows="4" name="message" value=""></textarea>

                </div>
                <div class="form-group">
                    <label for="attachement"> Attachment</label>
                    <div class="btn btn-attached">
                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                        <input name="attachment" type="file">
                        Add file .png/.jpg/.jpeg
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" class="button" value="Save">
                </div>

            </form>


        </div>

    </div>
    <div class="clearfix"></div>
</section>


@include("includes.footer")

