@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="{{route('addfaq')}}" class="btn btn-secondary btn-sm mb-3"
                               style="color:#fff"><i class="fa fa-plus" aria-hidden="true"></i> Add Page/Faq</a>
                        </div>
                    </div>
                </div>
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title">All Faqs/Pages</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table m-0">
                                <thead>
                                <tr>
                                    <th class="hide-on-mob">ID</th>
                                    <th class="">Title</th>
                                    <th class="">Identity</th>
                                    <th class="hide-on-mob">Operations</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($faqs as $single)
                                    <tr>

                                        <td class="hide-on-mob">

                                            <a href="/faq/{{$single->id}}">#{{$single->id}}</a>

                                        </td>
                                        <td class="">

                                            <a href="/faq/{{$single->id}}">{{ \Illuminate\Support\Str::limit($single->title, 100)  }}</a>

                                        </td>
                                        <td class="">
                                            {{$single->identity}}
                                        </td>
                                        <td class="hide-on-mob">


                                            <a href="/faqs/{{$single->id}}" class="btn btn-orange btn-sm">
                                                <i class="fa fa-pencil-alt" aria-hidden="true"></i>
                                                Edit </a>
                                            <a href="/deletefaq/{{$single->id}}"
                                               onclick="return confirm('Are you sure you want to delete this item?');"
                                               class="btn btn-danger btn-sm remove">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                Delete </a>
                                        </td>
                                    </tr>
                                @endforeach


                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                        <div class=" ml-3 mt-5 mb-5 mr-5">
                            {{ $faqs->onEachSide(5)->links() }}
                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')