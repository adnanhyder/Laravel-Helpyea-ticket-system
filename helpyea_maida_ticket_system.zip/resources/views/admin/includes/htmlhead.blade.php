<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@php
    $settingobject =  json_decode($settings) ;

@endphp
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- favicon icon -->
    <link rel="icon" href="@if(isset($settingobject->favicon)){{asset('img').'/'.$settingobject->favicon}}@endif"
          type="image/gif" sizes="16x16">
    <title>@if(isset($settingobject->title)){{$settingobject->title}}@else Helpyea @endif</title>


    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="{{asset('css/fontawesome.css')}}">
    <!-- admin style -->
    <link rel="stylesheet" href="{{asset('css/admin.css')}}">

    <!-- admin responsive style -->
    <link rel="stylesheet" href="{{asset('css/responsive-admin.css')}}">
    <!-- Google Font: Popins -->

    {{--<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
--}}
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

