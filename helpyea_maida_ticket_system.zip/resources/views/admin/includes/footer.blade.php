<!-- Main Footer -->
@php
    $settingobject =  json_decode($settings) ;
@endphp
<footer class="main-footer text-center">

    <p class="text-center text-md-left">
        {{$settingobject->copyrights}}
    </p>
</footer>

</div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="{{asset('js/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
<!-- Admin-->
<script src="{{asset('js/admin.min.js')}}"></script>
<script src="{{asset('js/custom.js')}}"></script>
</body>
</html>