@php
    $settingobject =  json_decode($settings) ;
@endphp
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{route('index')}}" class="brand-link">
        <img src="@if(isset($settingobject->logo)){{asset('img').'/'.$settingobject->logo}}@endif" alt="Logo" class="col-12">
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="{{asset('img/user').'/'.Auth::user()->profile_pic}}" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">{{Auth::user()->name }}  </a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">

            @if (Auth::user()->roles == "admin")
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="{{route('admin')}}" class="nav-link @if(isset($dashboard_active)) {{$dashboard_active}} @endif">
                        <span class="nav-icon fa ">D</span>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{route('users')}}" class="nav-link @if(isset($alluser_active)) {{$alluser_active}} @endif">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            All Users
                        </p>
                    </a>
                </li>
                @endif
                <li class="nav-item has-treeview @if(isset($menuopen)) {{$menuopen}} @endif">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fas fa-ticket-alt"></i>
                        <p>
                            Tickets
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ">
                        <li class="nav-item ">
                            <a href="{{route('tickets')}}" class="nav-link pl-5 @if(isset($allticket)) {{$allticket}} @endif">
                                <i class="far fa fa-folder-open nav-icon"></i>
                                <p>All</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route('ticketsOpen')}}" class="nav-link pl-5 @if(isset($ticketopen)) {{$ticketopen}} @endif">
                                <i class="far fa fa-folder-open nav-icon"></i>
                                <p>Open</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route('ticketsClose')}}" class="nav-link pl-5 @if(isset($ticketclose)) {{$ticketclose}} @endif">
                                <i class="far fa-times-circle nav-icon"></i>
                                <p>Close</p>
                            </a>
                        </li>
                    </ul>
                </li>
                @if (Auth::user()->roles == "admin")
                <li class="nav-item">
                    <a href="{{route('department')}}" class="nav-link @if(isset($department_active)) {{$department_active}} @endif">
                        <i class="nav-icon fa fa-sitemap"></i>
                        <p>
                            Departments
                        </p>
                    </a>
                </li>
                <li class="nav-item has-treeview @if(isset($settingmenuopen)) {{$settingmenuopen}} @endif">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fa fa-cogs"></i>
                        <p>
                            Setting
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{route('sitesetting')}}" class="nav-link pl-5 @if(isset($setting_active)) {{$setting_active}} @endif">
                                <i class="far fa fa-code nav-icon"></i>
                                <p>Site Setting</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route('faqs')}}" class="nav-link pl-5 @if(isset($faqs_active)) {{$faqs_active}} @endif">
                                <i class="fa fa-paragraph nav-icon"></i>
                                <p>Page/FAQ</p>
                            </a>
                        </li>
                    </ul>
                </li>
                @endif
                <li class="nav-item">
                    <a href="{{route('profile')}}" class="nav-link">
                        <i class="nav-icon fas fa-user-circle"></i>
                        <p>
                            Profile
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a  class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                    <form method="POST" action="{{ route('logout') }}">
                    @csrf
                        <button type="submit">Logout</button>
                    
                    </form>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
