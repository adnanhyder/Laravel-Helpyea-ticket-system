<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>

    </ul>


    {{--
    @todo this feature in version 2
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Messages Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" href="#">
                <i class="fa fa fa-heartbeat postbutton heartbeat animate-infinite-heartbeat"></i>
                <i class="far fa-bell"></i>

                <span class="badge badge-danger navbar-badge writeinfo">3</span>
            </a>

        </li>
    </ul>--}}
</nav>



<!-- /.navbar -->
