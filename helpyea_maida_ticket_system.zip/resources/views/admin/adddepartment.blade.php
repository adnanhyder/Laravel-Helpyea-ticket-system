@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')

<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')

<!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading pt-4 pl-4">
                        <h3 class="panel-title">Add/Edit Department</h3>
                    </div>
                    <div class="panel-body p-4">
                        <form class="form-horizontal" method="post" enctype="multipart/form-data" action="/submitdepartment">
                            {{ csrf_field() }}

                            <div class="col-sm-10">
                                @if(!empty($department->id))
                                    <input type="hidden" name="id" value="{{$department->id}}">
                                @endif



                                <div class="form-group">
                                    <label class="control-label" for="field-1">Department Name <span class="required">*</span></label>

                                    @if(!empty($department->department_name))
                                        <input type="text" id="field-1" class="form-control" placeholder="name"
                                               name="name"
                                               value="{{$department->department_name}}">
                                    @else
                                        <input type="text" id="field-1" class="form-control" placeholder="name"
                                               name="name"
                                               value="">
                                    @endif


                                </div>


                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="{{route('department')}}"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')