@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title">All Tickets</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table m-0">
                                <thead>
                                <tr>
                                    <th class="hide-on-mob">ID</th>
                                    <th class="">Ticket</th>
                                    <th class="">Status</th>
                                    <th class="hide-on-mob">Last Reply</th>
                                    <th class="hide-on-mob">Operations</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($tickets as $single)
                                    <tr>

                                        <td class="hide-on-mob">
                                            @if($single->ticket_status == "open")
                                                <a href="/tickets/{{$single->id}}">#{{$single->id}}</a>
                                            @else
                                                @if(Auth::user()->roles == "admin")
                                                    <a href="/tickets/{{$single->id}}">#{{$single->id}}</a>
                                                @else
                                                    <a href="#"
                                                       onclick="return confirm('please reopen first?');">#{{$single->id}}</a>
                                                @endif

                                            @endif
                                        </td>
                                        <td class="">
                                            @if($single->ticket_status == "open")
                                                <a href="/tickets/{{$single->id}}">{{ Str::limit($single->ticket_subject, 100)  }}</a>
                                            @else
                                                @if(Auth::user()->roles == "admin")
                                                    <a href="/tickets/{{$single->id}}">{{ Str::limit($single->ticket_subject, 100)  }}</a>
                                                @else
                                                    <a href="#"
                                                       onclick="return confirm('please reopen first?');">{{ Str::limit($single->ticket_subject, 100)  }}</a>
                                                @endif

                                            @endif
                                        </td>
                                        <td class=""><span
                                                    class="ticket_open @if($single->ticket_status == "open") btn-warning @else btn-danger @endif  ">{{ucfirst($single->ticket_status)}}</span>
                                        </td>
                                        <td class="hide-on-mob">{{$single->created_at}}</td>
                                        <td class="hide-on-mob">

                                            @if($single->ticket_status == "open")
                                                <a href="/tickets/{{$single->id}}" class="btn btn-orange btn-sm">
                                                    <i class="fa fa-reply" aria-hidden="true"></i>
                                                    Reply </a>
                                                <a href="/closeticket/{{$single->id}}"
                                                   onclick="return confirm('Are you sure you?');"
                                                   class="btn btn-warning btn-sm remove text-white">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                    Close </a>

                                            @else
                                                @if(Auth::user()->roles == "admin")
                                                    <a href="/reopenticket/{{$single->id}}"
                                                       onclick="return confirm('Are you sure you?');"
                                                       class="btn btn-warning btn-sm remove text-white">
                                                        <i class="fa fa-folder-open" aria-hidden="true"></i>
                                                        Reopen </a>
                                                @endif
                                            @endif
                                            @if(Auth::user()->roles == "admin")
                                                <a href="/deleteticket/{{$single->id}}"
                                                   onclick="return confirm('Are you sure you want to delete this item?');"
                                                   class="btn btn-danger btn-sm remove">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                    Delete </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach


                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                        <div class=" ml-3 mt-5 mb-5 mr-5">
                            {{ $tickets->onEachSide(5)->links() }}
                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')