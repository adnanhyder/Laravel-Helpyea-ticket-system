@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title"><b>Title: </b>{{$faq_detail->title}}</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>


                    <!-- /.card-header -->


                    <div class="card-body">
                        {{$faq_detail->description}}


                    </div>

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')