@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')

<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')

<!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading pt-4 pl-4">
                        <h3 class="panel-title">Add/Edit Page/Faq</h3>
                    </div>
                    <div class="panel-body p-4">
                        <form  class="form-horizontal" method="post" enctype="multipart/form-data" action="/submitfaq">
                            {{ csrf_field() }}

                            <div class="col-sm-10">
                                @if(!empty($faq->id))
                                    <input type="hidden" name="id" value="{{$faq->id}}">

                                @endif
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title <span class="required">*</span></label>

                                    @if(!empty($faq->id))
                                        <input type="text" id="field-1" class="form-control" placeholder="Title"
                                               name="title"
                                               value="{{$faq->title}}">
                                        <label class="control-label" for="field-1">Select Identity </label>

                                        <select name="identity" class="form-control" autocomplete="off">
                                            <option @if($faq->identity == "faq") selected="selected" @endif value="faq" >FAQ</option>
                                            <option @if($faq->identity == "page") selected="selected" @endif value="page">Page</option>
                                            <option @if($faq->identity == "homepagetagline1") selected="selected" @endif value="homepagetagline1">HomePage Tagline 1</option>
                                            <option @if($faq->identity == "homepagetagline2") selected="selected" @endif value="homepagetagline2">HomePage Tagline 2</option>

                                        </select>
                                        <label class="control-label" for="field-1">Description <span class="required">*</span></label>

                                        <textarea type="text" id="field-1" class="form-control unsetheigth"
                                                  rows="15"    name="description">{{$faq->description}}</textarea>


                                    @else
                                        <input type="text" id="field-1" class="form-control" placeholder="Title"
                                               name="title"
                                               value="">
                                        <label class="control-label" for="field-1">Select Identity </label>

                                        <select name="identity" class="form-control">
                                            <option value="faq" >FAQ</option>
                                            <option value="page">Page</option>
                                            <option value="homepagetagline1">HomePage Tagline 1</option>
                                            <option value="homepagetagline2">HomePage Tagline 2</option>

                                        </select>
                                        <label class="control-label" for="field-1">Description <span class="required">*</span></label>

                                        <textarea type="text" id="field-1" class="form-control unsetheigth"
                                                  rows="15"    name="description"
                                                  value=""></textarea>
                                    @endif

                                </div>


                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="{{route('department')}}"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')