@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
    <!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading p-4">
                        <h3 class="panel-title"> Users</h3>
                        <div class="panel-options float-right">
                            <a href="{{route('adduser')}}" class="btn btn-secondary btn-sm"
                               style="color:#fff"><i class="fa fa-user-plus" aria-hidden="true"></i> Add User</a>
                        </div>
                    </div>
                    <div class="panel-body p-4">
                        <div class="table-responsive">
                            <table class="table table-small-font table-bordered table-striped" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th class="hide-on-mob">Type</th>
                                    <th class="hide-on-mob">Status</th>
                                    <th class="hide-on-mob">Created</th>
                                    <th>Operations</th>
                                </tr>
                                </thead>

                                <tbody class="middle-align">

                                @foreach($users as $single)

                                    <tr>
                                        <td>
                                            <img src="{{asset('img/user')."/".$single->profile_pic}}"
                                                 class="img-circle img-inline userpic-32" width="28">
                                            {{ucfirst($single->name)}}
                                        </td>
                                        <td class="hide-on-mob"> {{ucfirst($single->roles)}}</td>

                                        <td class="hide-on-mob">
                                            <button class="btn @if($single->status =='active')btn-success @else btn-orange @endif btn-sm">{{ucfirst($single->status)}}</button>
                                        </td>
                                        <td class="hide-on-mob">{{$single->created_at}}</td>
                                        <td>
                                            <a href="/adduser/{{$single->id}}"
                                               class="btn btn-orange btn-sm">
                                                <i class="fa fa-pencil-alt" aria-hidden="true"></i>
                                                Edit </a>
                                            <a href="/deletuser/{{$single->id}}" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm remove">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                Delete </a>
                                        </td>
                                    </tr>
                                @endforeach

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')