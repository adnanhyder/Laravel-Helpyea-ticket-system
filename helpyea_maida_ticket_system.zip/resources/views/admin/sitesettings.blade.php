@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')

<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')

<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="panel panel-default card col-lg-12">
                <div class="panel-heading pt-4 pl-4">
                    <h3 class="panel-title">Add/Edit Settings</h3>
                </div>
                <div class="panel-body p-4">
                    <form class="form-horizontal" method="post" enctype="multipart/form-data"
                          action="/submitsettings">
                        {{ csrf_field() }}
                        @php
                            $settingobject =  json_decode($settings) ;

                        @endphp
                        @if(!empty($settingobject))
                            <div class="col-sm-10">
                                <input type="hidden" name="id" value="{{$id}}" >
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Facebook </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="facebook"
                                           value="{{$settingobject->facebook}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Twitter </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="twitter"
                                           value="{{$settingobject->twitter}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Phone </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="phone"
                                           value="{{$settingobject->phone}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Time </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="time"
                                           value="{{$settingobject->time}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Admin Email </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="email"admin_email
                                           value="{{$settingobject->admin_email}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Copyrights </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="copyrights"
                                           value="{{$settingobject->copyrights}}">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title </label>
                                    <input type="text" id="field-1" class="form-control"
                                           name="title"
                                           value="{{$settingobject->title}}">
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Logo</label>
                                    <label class="form-control upload-btn unsetheigth">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="logo">
                                        <img src="@if(isset($settingobject->logo)){{asset('img').'/'.$settingobject->logo}}@endif" class="img-upload"
                                             alt="logo">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Favicon</label>
                                    <label class="form-control upload-btn unsetheigth">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="favicon">
                                        <img src="@if(isset($settingobject->favicon)){{asset('img').'/'.$settingobject->favicon}}@endif" class="img-upload"
                                             alt="favicon">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="{{route('department')}}"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="col-sm-10">

                                <div class="form-group">
                                    <label class="control-label" for="field-1">Facebook </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="facebook"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Twitter </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="twitter"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Phone </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="phone"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Time </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="time"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Admin Email </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="email"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Copyrights </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="copyrights"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title </label>
                                    <input type="text" id="field-1" class="form-control"
                                           name="title"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Logo</label>
                                    <label class="form-control upload-btn">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="logo">
                                        <img src="" class="img-upload"
                                             alt="logo">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Favicon</label>
                                    <label class="form-control upload-btn">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="favicon">
                                        <img src="" class="img-upload"
                                             alt="favicon">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="{{route('department')}}"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')