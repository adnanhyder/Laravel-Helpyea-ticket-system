@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
    <!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading p-4">
                        <h3 class="panel-title"> Departments</h3>
                        <div class="panel-options float-right">
                            <a href="{{route('adddepartment')}}" class="btn btn-secondary btn-sm"
                               style="color:#fff"><i class="fa fa-sitemap" aria-hidden="true"></i> Add Department</a>
                        </div>
                    </div>
                    <div class="panel-body p-4">
                        <div class="table-responsive">
                            <table class="table m-0">

                                <thead>
                                <tr>
                                    <th>Name</th>

                                    <th class="hide-on-mob">Created</th>
                                    <th>Operations</th>
                                </tr>
                                </thead>

                                <tbody class="middle-align">

                                @foreach($departments as $single)

                                    <tr>
                                        <td>
                                            {{$single->department_name}}
                                        </td>
                                        <td class="hide-on-mob">{{$single->created_at}}</td>
                                        <td>
                                            <a href="/adddepartment/{{$single->id}}"
                                               class="btn btn-orange btn-sm">
                                                <i class="fa fa-pencil-alt" aria-hidden="true"></i>
                                                Edit </a>
                                            <a href="/deletdepartment/{{$single->id}}" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm remove">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                Delete </a>
                                        </td>
                                    </tr>
                                @endforeach

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')