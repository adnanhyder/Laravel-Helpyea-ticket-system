@include('admin.includes.htmlhead')
@include('admin.includes.nav')
@include('admin.includes.sidebar')
<!-- Content Wrapper. Contains page content -->
@include('admin.includes.message')
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                @if (Auth::user()->roles == "admin")

                    <div class="card ">
                        <div class="card-body p-0 mb-5">
                            <div class="list-replies reply-form">
                                <form method="post" action="/assignManger">
                                    {{csrf_field()}}
                                    <input type="hidden" name="id" value="{{base64_encode($id)}}">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label class="d-block p-0 col-lg-12">Assign Manager <span
                                                        class="font-weight-lighter float-right">Previous Assigned:  {{$tickets_assigned_user_name->name}} </span></label>
                                            <select class="form-control" name="assigned_user"
                                                    @if($tickets_status != "open") readonly @endif autocomplete="off">
                                                @foreach($managers as $single)
                                                    <option @if($tickets_assigned_user == $single->id) selected="selected"
                                                            @endif value="{{$single->id}}"> {{$single->name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="d-block p-0 col-lg-12">Assign Department <span
                                                        class="font-weight-lighter float-right">Previous Assigned:  {{$ticket_department_name->department_name}} </span></label>
                                            <select class="form-control" name="department"
                                                    @if($tickets_status != "open") readonly @endif autocomplete="off">
                                                @foreach($departments as $single)
                                                    <option @if($ticket_department_name->id == $single->id) selected="selected"
                                                            @endif value="{{$single->id}}"> {{$single->department_name}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            @if($tickets_status != "open")

                                            @else
                                                <input type="submit" class="button" value="Save">
                                            @endif
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title"><b>Ticket: </b>{{$tickets_subject}}</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>


                    <!-- /.card-header -->


                    <div class="card-body p-0">


                        @foreach($data as $single)

                            <div class="reply-block">
                                <div class="ticket-user">

                                    <img id="1357" class="img-circle img-responsive" alt="Adnanhyder"
                                         src="{{asset('img/user/').'/'.$single->submitted_userdata_picture}}">
                                </div>
                                <div class="ticket-msg">
                                    <div class="ticket-user-det">
                                        <b>{{$single->submitted_userdata_name}}</b> <span
                                                class="float-right">{{$single->created_at}}</span>
                                    </div>
                                    <p>{{$single->tickets_message}} </p>
                                    @if($single->ticket_attachment != "")
                                        <p>Attachment</p>
                                        <p><img src="{{asset('img/tickets/').'/'.$single->ticket_attachment}}"
                                                class="d-block img-thumbnail"></p>
                                    @endif
                                </div>
                            </div>

                        @endforeach
                    </div>

                    @if (Auth::user()->id == $tickets_assigned_user || Auth::user()->roles == "admin" && $tickets_status == "open")

                        <div class="list-replies reply-form">
                            <form method="post" action="/addticket" autocomplete="off" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <input type="hidden" name="id" value="{{base64_encode($id)}}">
                                <input type="hidden" name="tickets_assigned_user"
                                       value="{{base64_encode($tickets_assigned_user)}}">

                                <div class="form-group">
                                    <label for="message">Provide description <span
                                                class="required-field">*</span></label>
                                    <textarea class="form-control unsetheigth" rows="4" name="message"
                                              value=""></textarea>

                                </div>
                                <div class="form-group">
                                    <label for="attachement"> Attachment</label>
                                    <div class="btn btn-attached">
                                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                                        <input name="attachment" type="file">
                                        Add file .png/.jpg/.jpeg
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="button" value="Save">
                                </div>

                            </form>


                        </div>
                        <!-- /.card-body -->
                    @endif
                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@include('admin.includes.footer')