@include('includes.htmlhead')
<!--Header starting-->
@include('includes.header')
<!--Header ending-->
@include('includes.breadcrum')


<div class="post-section aboutus">
    <div class="container">

        <div class="radom">
            <div class="row">
            <!-- Heading Text  -->
                <div class="col-lg-12 ">
                    <div class="area-title pt-sm-5 pb-5">
                        <div class="content">
                            <h2 class="text-left  logo-green">{{$page->title}}</h2>
                            <div>{{$page->description}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

@include("includes.footer")