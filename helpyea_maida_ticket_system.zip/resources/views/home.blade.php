@include('includes.htmlhead')

@include('includes.header')

@include('includes.breadcrum')

<div class="container">

    @include('includes.message')
    <div class="row">
        <div class="col-md-12 text-right mt-5 mb-5">

            <a href="{{route('submit')}}" class="btn-ticket mt-0">
                <i class="fa fa-plus"></i> New Ticket
            </a>
        </div>
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="btn-group">
                                <button type="button" class="btn btn-info btn-filter" data-filter="all">All</button>
                                <button type="button" class="btn btn-warning  btn-filter" data-filter="open">Open
                                </button>
                                <button type="button" class="btn btn-danger btn-filter" data-filter="closed">Closed
                                </button>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="table-container">
                                <div class="table-responsive">
                                    <table class="table table-filter">
                                        <tbody>

                                        @foreach($tickets as $single)
                                            <tr class="filter @if($single->ticket_status == "open") open @else closed @endif  open pt-5 pb-5"
                                                style="">
                                                <td>
                                                    <a href="/ticket/{{$single->id}}">
                                                        #{{$single->id}}
                                                    </a>
                                                </td>
                                                <td>
                                                    <div class="media">
                                                        <a href="/ticket/{{$single->id}}"
                                                           class="media-body underlinehover">
                                                            <h4 class="ticket_title">
                                                                <b>{{$single->ticket_subject}}</b>
                                                            </h4>
                                                            <p class="question">{{ Str::limit($single->ticket_detail, 100)  }}</p>
                                                        </a>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="ticket_open @if($single->ticket_status == "open") btn-warning @else btn-danger @endif  ">{{ucfirst($single->ticket_status)}}</span>
                                                </td>
                                                <td class="text-right">
                                                    <span class="media-meta">{{$single->created_at}}</span>
                                                </td>
                                            </tr>
                                        @endforeach

                                        </tbody>
                                    </table>
                                    <div class=" ml-0 mt-5 mb-5 mr-5">
                                        {{ $tickets->onEachSide(5)->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@include("includes.footer")

