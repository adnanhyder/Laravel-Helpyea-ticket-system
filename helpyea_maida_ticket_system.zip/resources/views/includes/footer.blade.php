<!-- footer -->
<footer>

    <div class="copyright-area">
        <div class="container">
            <div class="row align-items-center">
                <!-- copyright -->
                @php
                    $settingobject =  json_decode($settings) ;
                    if(isset($menu)){
                     $menuobject =  json_decode($menu) ;
                    }
                @endphp
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p class="text-center text-md-left"><a href="">{{$settingobject->copyrights}}</a>
                    </p>
                </div>
                <!--end copyright -->

                <div class="col-lg-6 col-md-6 col-sm-6">
                    <ul class="list-inline text-center text-md-right">
                        @if(!empty($menuobject))
                            @foreach($menuobject as $single)
                                <li class="list-inline-item"><a href="{{$single->slug}}">{{$single->title}}</a></li>
                            @endforeach
                        @endif

                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


<!-- footer ending -->
<a href="#" class="scrollup" style="display: block;"><i class="fa-angle-up fa"></i></a>
<script src="{{ asset('js/jquery.min.js') }}" defer></script>
<script src="{{ asset('js/jquery.easing.min.js') }}" defer></script>
<script src="{{ asset('js/bootstrap.bundle.min.js') }}" defer></script>
<script src="{{ asset('js/custom.js') }}" defer></script>
</body>
</html>