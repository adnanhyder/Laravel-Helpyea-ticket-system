<header>
    <!--Header top bar starting-->
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-10">
                    <div class="header-top-info-list d-none d-md-block">
                        <!-- header top list time -->
                        @php
                            $settingobject =  json_decode($settings) ;

                        @endphp
                        <ul>
                            <li><i class="fas fa-envelope"></i> {{$settingobject->admin_email}}</li>
                            <li><i class="fas fa-mobile-alt"></i> {{$settingobject->phone}}</li>
                            <li><i class="fas fa-clock"></i> {{$settingobject->time}}</li>
                        </ul>
                    </div> <!-- header top list time end-->
                </div>
                <div class="col-lg-3 col-md-2">
                    <div class="header-top-social-icons text-center text-md-right">
                        <!-- header top social icons start-->
                        <ul>
                            <li><a href="{{$settingobject->facebook}}"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="{{$settingobject->twitter}}"><i class="fab fa-twitter-square"></i></a></li>

                        </ul>
                    </div> <!-- header top social icons -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    <!--Header top bar ending-->
    <!-- header menu and logo starting -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="navigation">
                    <nav class="navbar navbar-expand-lg   justify-content-between nav-color p-0">
                        <div class="navbar-header ">
                            <!--logo start-->
                            <a class="navbar-brand" href="{{route('index')}}">
                                <img src="{{asset('img/logo.png')}}" alt="logo" class="max-width-60px">
                            </a>
                            <!--end logo-->
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div> <!--nav bar header ending -->
                        <!--menu start-->
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="nav navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="{{route('index')}}">Home
                                        <span class="sr-only">(current)</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('faq') }}">Knowledge Base</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('contact') }}">Contact</a>
                                </li>
                                @guest
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('login') }}">Login</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('register') }}">Register</a>
                                    </li>
                                @else
                                    @if(Auth::user()->roles == "normal")
                                        <li class="nav-item">
                                            <a class="nav-link " href="{{ route('home') }}">Tickets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link " href="{{ route('submit') }}">Submit Ticket</a>
                                        </li>
                                    @else
                                        <li class="nav-item">
                                            <a class="nav-link" href="{{ route('admin') }}">Dashboard</a>
                                        </li>

                                    @endif
                                    <li class="nav-item d-sm-block d-md-block d-lg-none">
                                        <div class="dropdown " style="position: relative;">
                                            <a class="nav-link" href="#" id="user_profile_dropdown"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span
                                                        class="profile_pic_menu"><img
                                                            src="{{asset('img/user').'/'.Auth::user()->profile_pic}}"></span>
                                                <span>{{ Auth::user()->name }}</span> </a>
                                            <div class="dropdown-menu adjust_menu border pt-4 pb-4 radius-11"
                                                 aria-labelledby="user_profile_dropdown" style="position: absolute;">
                                                <div class="more-menu-caret">
                                                    <div class="more-menu-caret-outer"></div>
                                                    <div class="more-menu-caret-inner"></div>
                                                </div>
                                                <div class="row pl-4 pr-4">
                                                    <div class="col-md-auto">
                                                        <img src="{{asset('img/user').'/'.Auth::user()->profile_pic}}"
                                                             alt="User Image" class="rounded-circle" width="73px"
                                                             height="73px">
                                                    </div>
                                                    <div class="col-sm user_menu">
                                                        <strong>{{ Auth::user()->name }}</strong>
                                                        <p>{{ Auth::user()->email }}</p>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="{{route('profile')}}">Profile</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="{{ route('logout') }}"
                                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">{{ __('Sign Out') }}</a>
                                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                      style="display: none;">
                                                    @csrf
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="nav-item d-none d-lg-block position-relative">
                                        <a class="nav-link" href="#" id="user_profile_dropdown"><span
                                                    class="profile_pic_menu"><img
                                                        src="{{asset('img/user').'/'.Auth::user()->profile_pic}}"></span>
                                            <span class="uname_top">{{ Auth::user()->name }}</span> </a>

                                        <div class="dropdown dropleft  fade-out">
                                            <div class=" adjust_menu border pt-4 pb-4 radius-11"
                                                 aria-labelledby="user_profile_dropdown">
                                                <div class="more-menu-caret">
                                                    <div class="more-menu-caret-outer"></div>
                                                    <div class="more-menu-caret-inner"></div>
                                                </div>
                                                <div class="row pl-4 pr-4">
                                                    <div class="col-md-auto">
                                                        <img src="{{asset('img/user').'/'.Auth::user()->profile_pic}}"
                                                             alt="User Image" class="rounded-circle" width="73px"
                                                             height="73px">
                                                    </div>
                                                    <div class="col-sm user_menu">
                                                        <strong>{{ Auth::user()->name }}</strong>
                                                        <p>{{ Auth::user()->email }}</p>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>

                                                <a class="dropdown-item" href="{{route('profile')}}">Profile</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="{{ route('logout') }}"
                                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">{{ __('Sign Out') }}</a>
                                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                      style="display: none;">
                                                    @csrf
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                @endguest
                            </ul>
                        </div>
                        <!--menu end-->
                    </nav> <!--nav ending -->
                </div>
            </div>
        </div>
    </div>
    <!-- header menu and logo ending -->
</header>
