<!--Breadcrum start-->
<section class="breadcrumb-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="inner-heading">
                    @php $segments = ''; @endphp
                    @foreach(Request::segments() as $segment)
                        @php $segments .= '/'.$segment; @endphp
                        <h2>
                            {{ucfirst($segment)}}
                        </h2>
                    @endforeach

                </div>
            </div>
            <div class="col-lg-8 col-md-6 col-sm-12  hide-on-mob">
                <ul class="breadcrumb">
                    <li><a href="/"><i class="fa fa-home "></i></a><i class="fa fa-angle-right"></i></li>

                    @php $segments = ''; @endphp
                    @foreach(Request::segments() as $segment)
                        @php $segments .= '/'.$segment; @endphp
                        <li class="active">
                           {{ucfirst($segment)}}
                        </li>
                    @endforeach

                </ul>
            </div>
        </div>
    </div>
</section>
<!--Breadcrum end-->