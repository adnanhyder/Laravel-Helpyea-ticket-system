@extends('layouts.no_header')

@section('content')

    <div class="back-to-home rounded  d-block">
        <a href="{{route('index')}}" class="text-primary rounded d-inline-block text-center"><i class="fa fa-home"></i></a>
    </div>
    <!-- Hero Start -->

  @include('includes.message')
    <section class="vh-100" style="background: url('{{ asset('img/bg_login.jpg') }}') center center;">

        <div class="home-center">
            <div class="home-description-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6">
                            <div class="login-page bg-white shadow rounded p-4">
                                <div class="text-center">
                                    <h4 class="mb-4">{{__('Login')}}</h4>
                                </div>
                                <form method="POST" action="{{ route('login') }}" class="login-form">
                                    @csrf
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group position-relative">
                                                <label>{{__('E-Mail Address')}} <span
                                                            class="text-danger">*</span></label>
                                                <input type="email"
                                                       class="form-control @error('email') is-invalid @enderror"
                                                       placeholder="Email"
                                                       name="email"
                                                       value="{{ old('email') }}" required autocomplete="email"
                                                       autofocus>
                                            </div>
                                                @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                 <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-group position-relative">
                                                <label>{{__('Password')}} <span class="text-danger">*</span></label>
                                                <input type="password"
                                                       class="form-control @error('password') is-invalid @enderror"
                                                       placeholder="Password"
                                                       name="password"
                                                       required autocomplete="current-password">
                                            </div>
                                            @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>

                                        <div class="col-lg-12">
                                            <p class="float-right forgot-pass"><a href="{{ route('password.request') }}"
                                                                                  class="text-dark font-weight-bold">Forgot
                                                    password ?</a></p>
                                            <div class="form-group">
                                               
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-0">
                                            <button class="btn btn-primary w-100">{{ __('Sign in') }}</button>
                                        </div>
                                        <div class="col-12 text-center">
                                            <p class="mb-0 mt-3">
                                                <small class="text-dark mr-2">{{ __("Don't have an account ?") }}</small>
                                                <a href="{{ route('register') }}" class="text-dark font-weight-bold">{{ __('Sign Up') }}</a></p>
                                        </div>
                                    </div>
                                </form>
                            </div><!---->
                        </div> <!--end col-->
                    </div><!--end row-->
                </div> <!--end container-->
            </div>
        </div>
    </section><!--end section-->
    <!-- Hero End -->
@endsection







