@extends('layouts.no_header')

@section('content')

    <div class="back-to-home rounded  d-sm-block">
        <a href="{{route('index')}}" class="text-primary rounded d-inline-block text-center"><i class="fa fa-home"></i></a>
    </div>
    <!-- Hero Start -->
    @include('includes.message')
    <section class="vh-100" style="background: url('{{ asset('img/bg_login.jpg') }}') center center;">

        <div class="home-center">
            <div class="home-description-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6">
                            <div class="login_page bg-white shadow rounded p-4">
                                <div class="text-center">
                                    <h4 class="mb-4">{{ __('Signup') }}</h4>
                                </div>

                                    <form class="login-form" method="POST" action="{{ route('register') }}">
                                        @csrf
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="form-group position-relative">
                                                <label>{{ __('Name') }} <span class="text-danger">*</span></label>
                                                <input id="name" type="text"
                                                       class="form-control @error('name') is-invalid @enderror" name="name"
                                                       value="{{ old('name') }}" required autocomplete="name" autofocus>

                                                @error('name')
                                                <span class="invalid-feedback" role="alert">
                                                 <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group position-relative">
                                                <label>{{ __('Your Email') }} <span class="text-danger">*</span></label>
                                                <input id="email" type="email"
                                                       class="form-control @error('email') is-invalid @enderror" name="email"
                                                       value="{{ old('email') }}" required autocomplete="email">

                                                @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                     <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group position-relative">
                                                <label>{{ __('Password') }} <span class="text-danger">*</span></label>
                                                <input id="password" type="password"
                                                       class="form-control @error('password') is-invalid @enderror" name="password"
                                                       required autocomplete="new-password">

                                                @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                   <strong>{{ $message }}</strong>
                                                 </span>
                                                @enderror

                                                </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group position-relative">
                                                <label>{{ __('Confirm Password') }} <span class="text-danger">*</span></label>
                                                <input id="password-confirm" type="password" class="form-control"
                                                       name="password_confirmation" required autocomplete="new-password">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="custom-control m-0">
                                    
                                                    <label class="custom-control-label1" for="customCheck1">{{ __('By submitting You Accepted') }} <a href="#" class="text-primary">{{ __('Terms And Condition') }}</a></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <button class="btn btn-primary w-100">{{ __('Sign Up') }}</button>
                                        </div>
                                        <div class="mx-auto">
                                            <p class="mb-0 mt-3"><small class="text-dark mr-2">{{ __('Already have an account ?') }}</small> <a href="{{ route('login') }}" class="text-dark font-weight-bold">{{ __('Sign in') }}</a></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div> <!--end col-->
                    </div><!--end row-->
                </div> <!--end container-->
            </div>
        </div>
    </section><!--end section-->
    <!-- Hero End -->

@endsection
