Hello from <i>{{ $content->name }}</i>,
<p>
First Name :
    {{ $content->name }}
</p>
<p>
Last Name :
    {{ $content->lastname }}
</p>
<p>
Email :
    {{ $content->email }}
</p>
<p>
Message :

</p>
Thank you,


