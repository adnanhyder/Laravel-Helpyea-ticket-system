Hello,

<p>
    Status :
    {{ $content->status }}
</p>
<p>
    Message :
    {{$content->message}}
</p>
Thank you,



