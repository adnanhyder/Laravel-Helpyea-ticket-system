Hello,


Status :
{{ $content->status }}


Message :
{{$content->message}}

Thankyou

<img src="{{ $content->footerlogo }}">


Thank You,


