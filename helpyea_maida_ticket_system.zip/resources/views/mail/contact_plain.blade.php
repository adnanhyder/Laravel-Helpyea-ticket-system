Hello from {{ $content->name }},

First Name :
{{ $content->name }}

Last Name :<br>
{{ $content->lastname }}

Email :
{{ $content->email }}

Message :
{{ $content->message }}

