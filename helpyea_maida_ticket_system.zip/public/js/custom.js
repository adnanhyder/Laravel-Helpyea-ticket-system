(function () {
    /*setting consoles clearing start*/
    var method;
    var noop = function () {
    };
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeline', 'timelineEnd', 'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
    /* end setting consoles clearing*/


    /*start scroll to top */
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();
        } else {
            $('.scrollup').fadeOut();
        }
    });
    $('.scrollup').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 1000);
        return false;
    });

    /*end scroll to top */


    /*start of filters*/

    $(".btn-filter").click(function () {
        var value = $(this).attr('data-filter');

        if (value === "all") {
            $('.table tr').css('display', 'none').fadeIn('slow');
        } else {
            $('.table tr').css('display', 'none');
            $('.filter').filter('.' + value).fadeIn('slow');

        }
    });

    /*end of filter*/



}());

