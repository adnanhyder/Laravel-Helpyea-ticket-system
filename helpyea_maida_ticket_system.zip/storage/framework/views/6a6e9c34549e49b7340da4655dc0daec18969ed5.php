<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="showcase">
    <div class="container-fluid p-0">
        <div class="row no-gutters">

            <div class="col-lg-6 order-lg-2 text-white showcase-img"
                 style="background-image: url('<?php echo e(asset("img/services/iphone-472197_1920.jpg")); ?>');"></div>
            <div class="col-lg-6 order-lg-1 my-auto showcase-text">
                <?php if(!empty($tagline1->title)): ?>
                    <h2><?php echo e($tagline1->title); ?></h2>
                <?php endif; ?>
                <?php if(!empty($tagline1->description)): ?>
                    <p class="lead mb-0"><?php echo e($tagline1->description); ?></p>
                <?php endif; ?>
                <a href="<?php echo e(route('submit')); ?>" class="btn-ticket">
                    <i class="fas fa-ticket-alt"></i> Submit a Ticket
                </a>
            </div>
        </div>
        <div class="row no-gutters">
            <div class="col-lg-6 text-white showcase-img"
                 style="background-image: url('<?php echo e(asset("img/services/bg-showcase-2.jpg")); ?>');"></div>
            <div class="col-lg-6 my-auto showcase-text">
                <?php if(!empty($tagline2->title)): ?>
                    <h2><?php echo e($tagline2->title); ?></h2>
                <?php endif; ?>
                <?php if(!empty($tagline2->description)): ?>
                    <p class="lead mb-0"><?php echo e($tagline2->description); ?></p>
                <?php endif; ?>
                <a href="#" class="btn-ticket">
                    <i class="fas fa-ticket-alt"></i> Submit a Ticket
                </a>
            </div>
        </div>
    </div>
</section>
<section class="p-lg-5 p-md-0 p-sm-0">
    <div class="container">
        <div class="radom">
            <div class="row">

                <!-- Heading Text  -->
                <div class="col-lg-12 ">
                    <div class="area-title pt-sm-5 pb-5">
                        <div class="content">
                            <h2 class="text-center  logo-green">Frequently Asked Question</h2>
                            <div class="separate text-black-50"></div>
                            <h3 class="text-center text-black-50">Do You Want to Know</h3>
                        </div>
                    </div>
                </div>
                <?php if(!empty($faqs)): ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-6">
                            <a href="<?php echo e($single->slug); ?>" class="single_faq">
                                <h5>
                                    <?php echo e($single->title); ?> </h5>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class=" ml-3 mt-5 mb-5 mr-5">
                        <?php echo e($faqs->onEachSide(5)->links()); ?>

                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<section class="services-page-bg" style="background-image: url('<?php echo e(asset('img/blog/bg-cta.jpg')); ?>'); ">
    <div class="cta-content">
        <div class="container">
            <h2>Still no luck? We can help!</h2>
            <a href="#" class="btn-ticket">
                <i class="fas fa-ticket-alt"></i> Submit a Ticket
            </a>
        </div>
    </div>
    <div class="overlay"></div>
</section>

<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/helpyea/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>