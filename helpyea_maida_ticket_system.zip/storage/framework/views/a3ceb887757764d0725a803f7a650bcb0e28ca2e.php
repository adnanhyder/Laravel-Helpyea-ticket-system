Hello from <i><?php echo e($content->name); ?></i>,
<p>
First Name :
    <?php echo e($content->name); ?>

</p>
<p>
Last Name :
    <?php echo e($content->lastname); ?>

</p>
<p>
Email :
    <?php echo e($content->email); ?>

</p>
<p>
Message :

</p>
Thankyou

<img src="<?php echo e($content->footerlogo); ?>">



Thank You,
<br/>
<?php /**PATH E:\laragon\www\helpyea\resources\views/mail/contact.blade.php ENDPATH**/ ?>