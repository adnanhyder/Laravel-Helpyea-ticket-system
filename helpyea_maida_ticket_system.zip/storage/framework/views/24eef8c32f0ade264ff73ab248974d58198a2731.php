<!-- footer -->
<footer>

    <div class="copyright-area">
        <div class="container">
            <div class="row align-items-center">
                <!-- copyright -->
                <?php
                    $settingobject =  json_decode($settings) ;
                    if(isset($menu)){
                     $menuobject =  json_decode($menu) ;
                    }
                ?>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p class="text-center text-md-left"><a href=""><?php echo e($settingobject->copyrights); ?></a>
                    </p>
                </div>
                <!--end copyright -->

                <div class="col-lg-6 col-md-6 col-sm-6">
                    <ul class="list-inline text-center text-md-right">
                        <?php if(!empty($menuobject)): ?>
                            <?php $__currentLoopData = $menuobject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-inline-item"><a href="<?php echo e($single->slug); ?>"><?php echo e($single->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


<!-- footer ending -->
<a href="#" class="scrollup" style="display: block;"><i class="fa-angle-up fa"></i></a>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
</body>
</html><?php /**PATH /home/helpyea/public_html/resources/views/includes/footer.blade.php ENDPATH**/ ?>