<?php
    $settingobject =  json_decode($settings) ;
?>
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('index')); ?>" class="brand-link">
        <img src="<?php if(isset($settingobject->logo)): ?><?php echo e(asset('img').'/'.$settingobject->logo); ?><?php endif; ?>" alt="Logo" class="col-12">
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?>  </a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">

            <?php if(Auth::user()->roles == "admin"): ?>
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="<?php echo e(route('admin')); ?>" class="nav-link <?php if(isset($dashboard_active)): ?> <?php echo e($dashboard_active); ?> <?php endif; ?>">
                        <span class="nav-icon fa ">D</span>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('users')); ?>" class="nav-link <?php if(isset($alluser_active)): ?> <?php echo e($alluser_active); ?> <?php endif; ?>">
                        <i class="nav-icon fas fa-user"></i>
                        <p>
                            All Users
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item has-treeview <?php if(isset($menuopen)): ?> <?php echo e($menuopen); ?> <?php endif; ?>">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fas fa-ticket-alt"></i>
                        <p>
                            Tickets
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview ">
                        <li class="nav-item ">
                            <a href="<?php echo e(route('tickets')); ?>" class="nav-link pl-5 <?php if(isset($allticket)): ?> <?php echo e($allticket); ?> <?php endif; ?>">
                                <i class="far fa fa-folder-open nav-icon"></i>
                                <p>All</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('ticketsOpen')); ?>" class="nav-link pl-5 <?php if(isset($ticketopen)): ?> <?php echo e($ticketopen); ?> <?php endif; ?>">
                                <i class="far fa fa-folder-open nav-icon"></i>
                                <p>Open</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('ticketsClose')); ?>" class="nav-link pl-5 <?php if(isset($ticketclose)): ?> <?php echo e($ticketclose); ?> <?php endif; ?>">
                                <i class="far fa-times-circle nav-icon"></i>
                                <p>Close</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php if(Auth::user()->roles == "admin"): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('department')); ?>" class="nav-link <?php if(isset($department_active)): ?> <?php echo e($department_active); ?> <?php endif; ?>">
                        <i class="nav-icon fa fa-sitemap"></i>
                        <p>
                            Departments
                        </p>
                    </a>
                </li>
                <li class="nav-item has-treeview <?php if(isset($settingmenuopen)): ?> <?php echo e($settingmenuopen); ?> <?php endif; ?>">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fa fa-cogs"></i>
                        <p>
                            Setting
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('sitesetting')); ?>" class="nav-link pl-5 <?php if(isset($setting_active)): ?> <?php echo e($setting_active); ?> <?php endif; ?>">
                                <i class="far fa fa-code nav-icon"></i>
                                <p>Site Setting</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('faqs')); ?>" class="nav-link pl-5 <?php if(isset($faqs_active)): ?> <?php echo e($faqs_active); ?> <?php endif; ?>">
                                <i class="fa fa-paragraph nav-icon"></i>
                                <p>Page/FAQ</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('profile')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-user-circle"></i>
                        <p>
                            Profile
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a  class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                        <button type="submit">Logout</button>
                    
                    </form>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /home/helpyea/public_html/resources/views/admin/includes/sidebar.blade.php ENDPATH**/ ?>