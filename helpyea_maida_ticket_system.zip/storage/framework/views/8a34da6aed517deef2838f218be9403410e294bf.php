Hello,

<p>
    Status :
    <?php echo e($content->status); ?>

</p>
<p>
    Message :
    <?php echo e($content->message); ?>

</p>
Thank you,



<?php /**PATH E:\laragon\www\helpyea\resources\views/mail/notification.blade.php ENDPATH**/ ?>