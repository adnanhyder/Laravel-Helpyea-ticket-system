<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title">All Tickets</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table m-0">
                                <thead>
                                <tr>
                                    <th class="hide-on-mob">ID</th>
                                    <th class="">Ticket</th>
                                    <th class="">Status</th>
                                    <th class="hide-on-mob">Last Reply</th>
                                    <th class="hide-on-mob">Operations</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td class="hide-on-mob">
                                            <?php if($single->ticket_status == "open"): ?>
                                                <a href="/tickets/<?php echo e($single->id); ?>">#<?php echo e($single->id); ?></a>
                                            <?php else: ?>
                                                <?php if(Auth::user()->roles == "admin"): ?>
                                                    <a href="/tickets/<?php echo e($single->id); ?>">#<?php echo e($single->id); ?></a>
                                                <?php else: ?>
                                                    <a href="#"
                                                       onclick="return confirm('please reopen first?');">#<?php echo e($single->id); ?></a>
                                                <?php endif; ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="">
                                            <?php if($single->ticket_status == "open"): ?>
                                                <a href="/tickets/<?php echo e($single->id); ?>"><?php echo e(Str::limit($single->ticket_subject, 100)); ?></a>
                                            <?php else: ?>
                                                <?php if(Auth::user()->roles == "admin"): ?>
                                                    <a href="/tickets/<?php echo e($single->id); ?>"><?php echo e(Str::limit($single->ticket_subject, 100)); ?></a>
                                                <?php else: ?>
                                                    <a href="#"
                                                       onclick="return confirm('please reopen first?');"><?php echo e(Str::limit($single->ticket_subject, 100)); ?></a>
                                                <?php endif; ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class=""><span
                                                    class="ticket_open <?php if($single->ticket_status == "open"): ?> btn-warning <?php else: ?> btn-danger <?php endif; ?>  "><?php echo e(ucfirst($single->ticket_status)); ?></span>
                                        </td>
                                        <td class="hide-on-mob"><?php echo e($single->created_at); ?></td>
                                        <td class="hide-on-mob">

                                            <?php if($single->ticket_status == "open"): ?>
                                                <a href="/tickets/<?php echo e($single->id); ?>" class="btn btn-orange btn-sm">
                                                    <i class="fa fa-reply" aria-hidden="true"></i>
                                                    Reply </a>
                                                <a href="/closeticket/<?php echo e($single->id); ?>"
                                                   onclick="return confirm('Are you sure you?');"
                                                   class="btn btn-warning btn-sm remove text-white">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                    Close </a>

                                            <?php else: ?>
                                                <?php if(Auth::user()->roles == "admin"): ?>
                                                    <a href="/reopenticket/<?php echo e($single->id); ?>"
                                                       onclick="return confirm('Are you sure you?');"
                                                       class="btn btn-warning btn-sm remove text-white">
                                                        <i class="fa fa-folder-open" aria-hidden="true"></i>
                                                        Reopen </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->roles == "admin"): ?>
                                                <a href="/deleteticket/<?php echo e($single->id); ?>"
                                                   onclick="return confirm('Are you sure you want to delete this item?');"
                                                   class="btn btn-danger btn-sm remove">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                    Delete </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                        <div class=" ml-3 mt-5 mb-5 mr-5">
                            <?php echo e($tickets->onEachSide(5)->links()); ?>

                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/helpyea/public_html/resources/views/admin/tickets.blade.php ENDPATH**/ ?>