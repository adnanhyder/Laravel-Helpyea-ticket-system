<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="">
                    <div class="row">
                        <div class="col-lg-4">
                            <a href="<?php echo e(route('addfaq')); ?>" class="btn btn-secondary btn-sm mb-3"
                               style="color:#fff"><i class="fa fa-plus" aria-hidden="true"></i> Add Page/Faq</a>
                        </div>
                    </div>
                </div>
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title">All Faqs/Pages</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table m-0">
                                <thead>
                                <tr>
                                    <th class="hide-on-mob">ID</th>
                                    <th class="">Title</th>
                                    <th class="">Identity</th>
                                    <th class="hide-on-mob">Operations</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td class="hide-on-mob">

                                            <a href="/faq/<?php echo e($single->id); ?>">#<?php echo e($single->id); ?></a>

                                        </td>
                                        <td class="">

                                            <a href="/faq/<?php echo e($single->id); ?>"><?php echo e(\Illuminate\Support\Str::limit($single->title, 100)); ?></a>

                                        </td>
                                        <td class="">
                                            <?php echo e($single->identity); ?>

                                        </td>
                                        <td class="hide-on-mob">


                                            <a href="/faqs/<?php echo e($single->id); ?>" class="btn btn-orange btn-sm">
                                                <i class="fa fa-pencil-alt" aria-hidden="true"></i>
                                                Edit </a>
                                            <a href="/deletefaq/<?php echo e($single->id); ?>"
                                               onclick="return confirm('Are you sure you want to delete this item?');"
                                               class="btn btn-danger btn-sm remove">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                Delete </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                        <div class=" ml-3 mt-5 mb-5 mr-5">
                            <?php echo e($faqs->onEachSide(5)->links()); ?>

                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/faqs.blade.php ENDPATH**/ ?>