<!--Breadcrum start-->
<section class="breadcrumb-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="inner-heading">
                    <?php $segments = ''; ?>
                    <?php $__currentLoopData = Request::segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $segments .= '/'.$segment; ?>
                        <h2>
                            <?php echo e(ucfirst($segment)); ?>

                        </h2>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="col-lg-8 col-md-6 col-sm-12  hide-on-mob">
                <ul class="breadcrumb">
                    <li><a href="/"><i class="fa fa-home "></i></a><i class="fa fa-angle-right"></i></li>

                    <?php $segments = ''; ?>
                    <?php $__currentLoopData = Request::segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $segments .= '/'.$segment; ?>
                        <li class="active">
                           <?php echo e(ucfirst($segment)); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
    </div>
</section>
<!--Breadcrum end--><?php /**PATH E:\laragon\www\helpyea\resources\views/includes/breadcrum.blade.php ENDPATH**/ ?>