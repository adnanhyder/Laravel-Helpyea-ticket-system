<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="white section pt-5 pb-5">
    <div class="container">

        <div class="list-replies">

            <h1><b>Ticket: </b><?php echo e($tickets_subject); ?> <span class="float-right"><b>Assigned To: </b>  <?php echo e($tickets_assigned_user_name->name); ?> <b> Department: </b>   <?php echo e($ticket_department_name->department_name); ?></span></h1>


            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="reply-block">
                    <div class="ticket-user">

                        <img id="1357" class="img-circle img-responsive" alt="Adnanhyder"
                             src="<?php echo e(asset('img/user/').'/'.$single->submitted_userdata_picture); ?>">
                    </div>
                    <div class="ticket-msg">
                        <div class="ticket-user-det">
                            <b><?php echo e($single->submitted_userdata_name); ?></b> <span class="float-right"><?php echo e($single->created_at); ?></span>
                        </div>
                        <p><?php echo e($single->tickets_message); ?> </p>
                        <?php if($single->ticket_attachment != ""): ?>
                        <p>Attachment</p>
                        <p><img src="<?php echo e(asset('img/tickets/').'/'.$single->ticket_attachment); ?>" class="d-block img-thumbnail"> </p>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="clearfix"></div>
        </div>
        <div class="list-replies reply-form">
            <form method="post" action="/addticket" autocomplete="off" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e(base64_encode($id)); ?>">
                <input type="hidden" name="tickets_assigned_user" value="<?php echo e(base64_encode($tickets_assigned_user)); ?>">
                <div class="form-group">
                    <label for="message">Provide description <span class="required-field">*</span></label>
                    <textarea class="form-control unsetheigth" rows="4" name="message" value=""></textarea>

                </div>
                <div class="form-group">
                    <label for="attachement"> Attachment</label>
                    <div class="btn btn-attached">
                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                        <input name="attachment" type="file">
                        Add file .png/.jpg/.jpeg
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" class="button" value="Save">
                </div>

            </form>


        </div>

    </div>
    <div class="clearfix"></div>
</section>


<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH E:\laragon\www\helpyea\resources\views/ticket.blade.php ENDPATH**/ ?>