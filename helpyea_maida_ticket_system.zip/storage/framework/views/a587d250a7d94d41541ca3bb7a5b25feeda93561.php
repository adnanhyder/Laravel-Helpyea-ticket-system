<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title"><b>Title: </b><?php echo e($faq_detail->title); ?></h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>


                    <!-- /.card-header -->


                    <div class="card-body">
                        <?php echo e($faq_detail->description); ?>



                    </div>

                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/faq.blade.php ENDPATH**/ ?>