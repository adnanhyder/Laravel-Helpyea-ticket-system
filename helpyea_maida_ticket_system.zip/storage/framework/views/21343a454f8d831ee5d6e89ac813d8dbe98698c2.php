<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php
        $settingobject =  json_decode($settings) ;

    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- favicon icon -->
    <link rel="icon" href="<?php echo e(asset('img/fav.png')); ?>" type="image/gif" sizes="16x16">
    <title><?php if(isset($settingobject->title)): ?><?php echo e($settingobject->title); ?><?php else: ?> Helpyea <?php endif; ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">


</head>
<body><?php /**PATH E:\laragon\www\helpyea\resources\views/includes/htmlhead.blade.php ENDPATH**/ ?>