Hello,


Status :
<?php echo e($content->status); ?>



Message :
<?php echo e($content->message); ?>


Thankyou

<img src="<?php echo e($content->footerlogo); ?>">


Thank You,


<?php /**PATH E:\laragon\www\helpyea\resources\views/mail/notification_plain.blade.php ENDPATH**/ ?>