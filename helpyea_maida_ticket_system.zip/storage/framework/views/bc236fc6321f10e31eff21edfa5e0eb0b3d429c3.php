<?php $__env->startSection('content'); ?>

    <div class="back-to-home rounded  d-block">
        <a href="<?php echo e(route('index')); ?>" class="text-primary rounded d-inline-block text-center"><i class="fa fa-home"></i></a>
    </div>
    <!-- Hero Start -->

  <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="vh-100" style="background: url('<?php echo e(asset('img/bg_login.jpg')); ?>') center center;">

        <div class="home-center">
            <div class="home-description-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6">
                            <div class="login-page bg-white shadow rounded p-4">
                                <div class="text-center">
                                    <h4 class="mb-4"><?php echo e(__('Login')); ?></h4>
                                </div>
                                <form method="POST" action="<?php echo e(route('login')); ?>" class="login-form">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group position-relative">
                                                <label><?php echo e(__('E-Mail Address')); ?> <span
                                                            class="text-danger">*</span></label>
                                                <input type="email"
                                                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       placeholder="Email"
                                                       name="email"
                                                       value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                                       autofocus>
                                            </div>
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                 <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-group position-relative">
                                                <label><?php echo e(__('Password')); ?> <span class="text-danger">*</span></label>
                                                <input type="password"
                                                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       placeholder="Password"
                                                       name="password"
                                                       required autocomplete="current-password">
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-lg-12">
                                            <p class="float-right forgot-pass"><a href="<?php echo e(route('password.request')); ?>"
                                                                                  class="text-dark font-weight-bold">Forgot
                                                    password ?</a></p>
                                            <div class="form-group">
                                                <div class="custom-control m-0 custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input"
                                                           name="remember"
                                                           id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label" for="remember" ><?php echo e(__('Remember Me')); ?></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 mb-0">
                                            <button class="btn btn-primary w-100"><?php echo e(__('Sign in')); ?></button>
                                        </div>
                                        <div class="col-12 text-center">
                                            <p class="mb-0 mt-3">
                                                <small class="text-dark mr-2"><?php echo e(__("Don't have an account ?")); ?></small>
                                                <a href="<?php echo e(route('register')); ?>" class="text-dark font-weight-bold"><?php echo e(__('Sign Up')); ?></a></p>
                                        </div>
                                    </div>
                                </form>
                            </div><!---->
                        </div> <!--end col-->
                    </div><!--end row-->
                </div> <!--end container-->
            </div>
        </div>
    </section><!--end section-->
    <!-- Hero End -->
<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.no_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/helpyea/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>