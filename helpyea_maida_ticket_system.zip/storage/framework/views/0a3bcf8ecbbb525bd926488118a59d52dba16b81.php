<header>
    <!--Header top bar starting-->
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-8">
                    <div class="header-top-info-list d-none d-md-block">
                        <!-- header top list time -->
                        <ul>
                            <li><i class="fas fa-envelope"></i> info@abc.com</li>
                            <li><i class="fas fa-mobile-alt"></i> +12345689456</li>
                            <li><i class="fas fa-clock"></i> 9AM to 5PM (Mon - Fri)</li>
                        </ul>
                    </div> <!-- header top list time end-->
                </div>
                <div class="col-lg-5 col-md-4">
                    <div class="header-top-social-icons text-right">
                        <!-- header top social icons start-->
                        <ul>
                            <li><a href="javascript:void(0)"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="javascript:void(0)"><i class="fab fa-twitter-square"></i></a></li>

                        </ul>
                    </div> <!-- header top social icons -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    <!--Header top bar ending-->
    <!-- header menu and logo starting -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="navigation">
                    <nav class="navbar navbar-expand-lg   justify-content-between nav-color pl-0 pr-0">
                        <div class="navbar-header ">
                            <!--logo start-->
                            <a class="navbar-brand" href="/">
                                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" class="max-width-60px">
                            </a>
                            <!--end logo-->
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div> <!--nav bar header ending -->
                        <!--menu start-->
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="nav navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home
                                        <span class="sr-only">(current)</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                       aria-expanded="false"
                                       class="nav-link dropdown-toggle"><i class="fa fa-user"></i> Pages </a>
                                    <ul class="dropdown-menu border-0 shadow">
                                        <li><a href="404.html" class="dropdown-item">404 </a></li>
                                        <li><a href="services.html" class="dropdown-item">Services </a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--menu end-->
                    </nav> <!--nav ending -->
                </div>
            </div>
        </div>
    </div>
    <!-- header menu and logo ending -->
</header>
<?php /**PATH E:\laragon\www\helpyea\resources\views/includes/header.blade.php ENDPATH**/ ?>