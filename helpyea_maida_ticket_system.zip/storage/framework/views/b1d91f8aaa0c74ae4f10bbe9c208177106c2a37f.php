Hello from <?php echo e($content->name); ?>,

First Name :
<?php echo e($content->name); ?>


Last Name :<br>
<?php echo e($content->lastname); ?>


Email :
<?php echo e($content->email); ?>


Message :
<?php echo e($content->message); ?>


<?php /**PATH E:\laragon\www\helpyea\resources\views/mail/contact_plain.blade.php ENDPATH**/ ?>