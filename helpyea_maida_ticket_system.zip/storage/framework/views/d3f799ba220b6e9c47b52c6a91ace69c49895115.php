<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading p-4">
                        <h3 class="panel-title"> Departments</h3>
                        <div class="panel-options float-right">
                            <a href="<?php echo e(route('adddepartment')); ?>" class="btn btn-secondary btn-sm"
                               style="color:#fff"><i class="fa fa-sitemap" aria-hidden="true"></i> Add Department</a>
                        </div>
                    </div>
                    <div class="panel-body p-4">
                        <div class="table-responsive">
                            <table class="table m-0">

                                <thead>
                                <tr>
                                    <th>Name</th>

                                    <th class="hide-on-mob">Created</th>
                                    <th>Operations</th>
                                </tr>
                                </thead>

                                <tbody class="middle-align">

                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td>
                                            <?php echo e($single->department_name); ?>

                                        </td>
                                        <td class="hide-on-mob"><?php echo e($single->created_at); ?></td>
                                        <td>
                                            <a href="/adddepartment/<?php echo e($single->id); ?>"
                                               class="btn btn-orange btn-sm">
                                                <i class="fa fa-pencil-alt" aria-hidden="true"></i>
                                                Edit </a>
                                            <a href="/deletdepartment/<?php echo e($single->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm remove">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                                Delete </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/department.blade.php ENDPATH**/ ?>