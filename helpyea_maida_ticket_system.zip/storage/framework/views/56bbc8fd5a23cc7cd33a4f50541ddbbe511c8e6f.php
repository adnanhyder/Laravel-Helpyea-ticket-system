<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header starting-->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header ending-->

<?php echo $__env->make('includes.breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Contact section Start-->
<section class="services-page-bg mb-5" style="background-image: url('<?php echo e(asset('img/blog/bg-cta.jpg')); ?>'); ">
    <div class="cta-content">
        <div class="container">
            <h2>Still no luck? We can help!</h2>
            <a href="#" class="btn-ticket">
                <i class="fas fa-ticket-alt"></i> Submit a Ticket
            </a>
        </div>
    </div>
    <div class="overlay"></div>
</section>




    <div class="container">
        <div class="col-lg-12">
            <div class="area-title pb-5">
                <div class="content">
                    <h2 class="text-center  logo-green">Contact Us</h2>
                    <div class="separate text-black-50"></div>
                    <h3 class="text-center text-black-50">We Support You 24/7</h3>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="contact-form-area">
                    <div class="contact-form p-4">
                        <form action="/mail/send" class="row" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="text" required="required" class="col-lg-5 col-md-12 " name="name" placeholder="First Name">
                            <input required="required"  class="offset-lg-2 col-lg-5 col-md-12 " name="lastname" type="text" placeholder="Last Name">
                            <input type="email" required="required"  name="email" placeholder="Enter your email">
                            <textarea placeholder="Write your message" name="message"></textarea>

                            <div class="mt-4 ml-auto mr-auto col-lg-3 col-md-6 p-0">
                                <button type="submit" class="btn-ticket  custom-button">Send</button>
                            </div>

                        </form>
                    </div>


                </div>
            </div>
        </div>
    </div>

</section>
<!--Contact section ending-->

<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/contact.blade.php ENDPATH**/ ?>