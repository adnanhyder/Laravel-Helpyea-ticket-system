<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading pt-4 pl-4">
                        <h3 class="panel-title">Add/Edit Users</h3>
                    </div>
                    <div class="panel-body p-4">
                        <form class="form-horizontal" method="post" enctype="multipart/form-data" action="/submituser">
                            <?php echo e(csrf_field()); ?>


                            <div class="col-sm-10">
                                <?php if(!empty($user->id)): ?>
                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                <?php endif; ?>
                                <div class="form-group">
                                    <label>User Type</label>
                                    <select class="form-control" name="user_role" autocomplete="off">
                                        <option>Select ...</option>
                                        <?php if(!empty($user->roles)): ?>
                                            <option <?php if($user->roles == "admin"): ?> selected="selected"
                                                    <?php endif; ?> value="admin">
                                                Admin
                                            </option>
                                            <option <?php if($user->roles == "manager"): ?> selected="selected"
                                                    <?php endif; ?> value="manager">Manager
                                            </option>
                                            <option <?php if($user->roles == "normal"): ?> selected="selected"
                                                    <?php endif; ?> value="normal">Normal User
                                            </option>
                                        <?php else: ?>
                                            <option  value="admin"> Admin</option>
                                            <option value="manager">Manager</option>
                                            <option value="normal">Normal User</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <?php if(!empty($user->email)): ?>
                                        <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                                               placeholder="Enter email" readonly value="<?php echo e($user->email); ?>">
                                    <?php else: ?>
                                        <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                                               placeholder="Enter email" value="">
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="field-1">Username <span class="required">*</span></label>

                                    <?php if(!empty($user->name)): ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="Username"
                                               name="name"
                                               value="<?php echo e($user->name); ?>">
                                    <?php else: ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="Username"
                                               name="name"
                                               value="">
                                    <?php endif; ?>


                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Password <span class="required">*</span></label>

                                    <div class="">
                                        <input type="password" class="form-control" placeholder="Leave Blank if dont want to change"
                                               name="password" value="">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label">First Name</label>

                                    <?php if(!empty($user->firstname)): ?>

                                        <input type="text" class="form-control" placeholder="First Name"
                                               name="firstname" value="<?php echo e($user->firstname); ?>">
                                    <?php else: ?>
                                        <input type="text" class="form-control" placeholder="First Name"
                                               name="firstname" value="">
                                    <?php endif; ?>

                                </div>
                                <div class="form-group">
                                    <label class=" control-label">Last Name</label>

                                    <?php if(!empty($user->lastname)): ?>
                                        <input type="text" class="form-control" placeholder="Last Name" name="lastname"
                                               value="<?php echo e($user->lastname); ?>">
                                    <?php else: ?>
                                        <input type="text" class="form-control" placeholder="Last Name" name="lastname"
                                               value="">
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Image <span
                                                class="required">*</span></label>
                                    <div class="">
                                        <input class="form-control" type="file" name="image">
                                    </div>
                                    <div class="col-sm-2 mt-3 mb-3 ml-0">
                                        <?php if(!empty($user->profile_pic)): ?>
                                            <img src="<?php echo e(asset('img/user')."/".$user->profile_pic); ?>"
                                                 class=" img-inline userpic-32" width="28">
                                        <?php endif; ?>
                                    </div>
                                </div>


                                <div class="form-group col-lg-12 float-left">
                                    <label class="control-label" for="field-1"> Status</label>
                                    <?php if(!empty($user->status)): ?>
                                    <div class="compose-message-editor ">
                                        <input type="radio" <?php if($user->status == "active"): ?> checked="checked"
                                               <?php endif; ?> value="active" name="status">
                                        Active<br>
                                        <input type="radio" <?php if($user->status == "inactive"): ?> checked="checked"
                                               <?php endif; ?> value="inactive" name="status"> Inactive
                                    </div>
                                        <?php else: ?>
                                        <div class="compose-message-editor ">
                                            <input type="radio" value="active" name="status">
                                            Active<br>
                                            <input type="radio"  value="inactive" name="status"> Inactive
                                        </div>
                                        <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="<?php echo e(route('users')); ?>"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/helpyea/public_html/resources/views/admin/adduser.blade.php ENDPATH**/ ?>