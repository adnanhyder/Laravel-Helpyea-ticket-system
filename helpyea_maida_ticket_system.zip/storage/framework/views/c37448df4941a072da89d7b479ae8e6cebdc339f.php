<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading pt-4 pl-4">
                        <h3 class="panel-title">Add/Edit Department</h3>
                    </div>
                    <div class="panel-body p-4">
                        <form class="form-horizontal" method="post" enctype="multipart/form-data" action="/submitdepartment">
                            <?php echo e(csrf_field()); ?>


                            <div class="col-sm-10">
                                <?php if(!empty($department->id)): ?>
                                    <input type="hidden" name="id" value="<?php echo e($department->id); ?>">
                                <?php endif; ?>



                                <div class="form-group">
                                    <label class="control-label" for="field-1">Department Name <span class="required">*</span></label>

                                    <?php if(!empty($department->department_name)): ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="name"
                                               name="name"
                                               value="<?php echo e($department->department_name); ?>">
                                    <?php else: ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="name"
                                               name="name"
                                               value="">
                                    <?php endif; ?>


                                </div>


                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="<?php echo e(route('department')); ?>"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/adddepartment.blade.php ENDPATH**/ ?>