<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">


                    <div class="col-lg-4">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?php echo e($ticketstotal); ?></h3>

                                <p>Tickets</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                            <a href="<?php echo e(route('tickets')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->

                    <div class="col-lg-4 ">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?php echo e(count($users)); ?></h3>

                                <p>User Registrations</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-users"></i>
                            </div>
                            <a href="<?php echo e(route('users')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 ">
                        <!-- small box -->
                        <div class="small-box bg-gradient-danger">
                            <div class="inner">
                                <h3><?php echo e($departmenttotal); ?></h3>

                                <p>Departments</p>
                            </div>
                            <div class="icon">
                                <i class="fa fa-sitemap"></i>
                            </div>
                            <a href="<?php echo e(route('department')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->


            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12 ">
                    <div class="card ">
                        <div class="card-header border-transparent">
                            <h3 class="card-title">Latest Tickets</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>

                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table m-0">
                                    <thead>
                                    <tr>
                                        <th class="hide-on-mob">ID</th>
                                        <th class="">Ticket</th>
                                        <th class="">Status</th>
                                        <th class="hide-on-mob">Last Reply</th>
                                        <th class="hide-on-mob">Operations</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td class="hide-on-mob"><a href="/tickets/<?php echo e($single->id); ?>">#<?php echo e($single->id); ?></a></td>
                                            <td class=""><a href="/tickets/<?php echo e($single->id); ?>"><?php echo e(Str::limit($single->ticket_subject, 100)); ?></a></td>
                                            <td class=""><span class="ticket_open <?php if($single->ticket_status == "open"): ?> btn-warning <?php else: ?> btn-danger <?php endif; ?>  "><?php echo e(ucfirst($single->ticket_status)); ?></span></td>
                                            <td class="hide-on-mob"><?php echo e($single->created_at); ?></td>
                                            <td class="hide-on-mob">

                                                <a href="/tickets/<?php echo e($single->id); ?>" class="btn btn-orange btn-sm">
                                                    <i class="fa fa-reply" aria-hidden="true"></i>
                                                    Reply </a>
                                                <a href="#" class="btn btn-warning btn-sm remove text-white">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                    Close </a>
                                                <a href="#" class="btn btn-danger btn-sm remove">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                    Delete </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                           <a href="<?php echo e(route('tickets')); ?>" class="btn btn-sm btn-secondary float-right">View All
                                Tickets</a>
                        </div>
                        <!-- /.card-footer -->
                    </div>
                </div>
                <!-- ./col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>