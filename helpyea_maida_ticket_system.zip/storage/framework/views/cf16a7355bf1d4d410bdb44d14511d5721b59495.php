<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="panel panel-default card col-lg-12">
                <div class="panel-heading pt-4 pl-4">
                    <h3 class="panel-title">Add/Edit Settings</h3>
                </div>
                <div class="panel-body p-4">
                    <form class="form-horizontal" method="post" enctype="multipart/form-data"
                          action="/submitsettings">
                        <?php echo e(csrf_field()); ?>

                        <?php
                            $settingobject =  json_decode($settings) ;

                        ?>
                        <?php if(!empty($settingobject)): ?>
                            <div class="col-sm-10">
                                <input type="hidden" name="id" value="<?php echo e($id); ?>" >
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Facebook </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="facebook"
                                           value="<?php echo e($settingobject->facebook); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Twitter </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="twitter"
                                           value="<?php echo e($settingobject->twitter); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Phone </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="phone"
                                           value="<?php echo e($settingobject->phone); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Time </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="time"
                                           value="<?php echo e($settingobject->time); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Admin Email </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="email"admin_email
                                           value="<?php echo e($settingobject->admin_email); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Copyrights </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="copyrights"
                                           value="<?php echo e($settingobject->copyrights); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title </label>
                                    <input type="text" id="field-1" class="form-control"
                                           name="title"
                                           value="<?php echo e($settingobject->title); ?>">
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Logo</label>
                                    <label class="form-control upload-btn unsetheigth">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="logo">
                                        <img src="<?php if(isset($settingobject->logo)): ?><?php echo e(asset('img').'/'.$settingobject->logo); ?><?php endif; ?>" class="img-upload"
                                             alt="logo">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Favicon</label>
                                    <label class="form-control upload-btn unsetheigth">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="favicon">
                                        <img src="<?php if(isset($settingobject->favicon)): ?><?php echo e(asset('img').'/'.$settingobject->favicon); ?><?php endif; ?>" class="img-upload"
                                             alt="favicon">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="<?php echo e(route('department')); ?>"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-sm-10">

                                <div class="form-group">
                                    <label class="control-label" for="field-1">Facebook </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="facebook"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Twitter </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="twitter"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Phone </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="phone"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Time </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="time"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Admin Email </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="email"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Copyrights </label>
                                    <input type="text" id="field-1" class="form-control" placeholder=""
                                           name="copyrights"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title </label>
                                    <input type="text" id="field-1" class="form-control"
                                           name="title"
                                           value="">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Logo</label>
                                    <label class="form-control upload-btn">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="logo">
                                        <img src="" class="img-upload"
                                             alt="logo">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Favicon</label>
                                    <label class="form-control upload-btn">
                                        <i class="fa fa-upload"></i> Upload <input type="file" name="favicon">
                                        <img src="" class="img-upload"
                                             alt="favicon">
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="<?php echo e(route('department')); ?>"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/helpyea/public_html/resources/views/admin/sitesettings.blade.php ENDPATH**/ ?>