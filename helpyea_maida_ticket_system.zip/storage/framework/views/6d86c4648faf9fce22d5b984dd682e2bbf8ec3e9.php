<!-- Main Footer -->
<?php
    $settingobject =  json_decode($settings) ;
?>
<footer class="main-footer text-center">

    <p class="text-center text-md-left">
        <?php echo e($settingobject->copyrights); ?>

    </p>
</footer>

</div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Admin-->
<script src="<?php echo e(asset('js/admin.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>
</html><?php /**PATH /home/helpyea/public_html/resources/views/admin/includes/footer.blade.php ENDPATH**/ ?>