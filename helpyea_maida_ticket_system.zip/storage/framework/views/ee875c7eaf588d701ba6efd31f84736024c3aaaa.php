<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header starting-->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header ending-->
<?php echo $__env->make('includes.breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="post-section aboutus">
    <div class="container">

        <div class="radom">
            <div class="row">
            <!-- Heading Text  -->
                <div class="col-lg-12 ">
                    <div class="area-title pt-sm-5 pb-5">
                        <div class="content">
                            <h2 class="text-left  logo-green"><?php echo e($page->title); ?></h2>
                            <div><?php echo e($page->description); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/page.blade.php ENDPATH**/ ?>