<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="profileheader"
     style="background: linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.09)), url('<?php echo e(asset('img/user/lola_profile_bg.jpeg')); ?>');">
    <div class="container">
        <div class="userprofile" style="background-image: url('<?php echo e(asset("img/user")."/".Auth::user()->profile_pic); ?>')">
        </div>
    </div>
</div>

<section class="white section pt-5 pb-5">
    <div class="container reply-form">
        <div class="col-md-8 offset-md-2">
            <form method="post" class="edit-profile" action="/updateprofile" enctype="multipart/form-data">
                <h3>Update Your Profile</h3>
                <div class="row">
                </div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="encodedstring" value="<?php echo e(base64_encode(Auth::user()->id)); ?>">
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="firstname"> First Name</label>
                        <input class="form-control" type="text" name="firstname" value="<?php echo e(Auth::user()->firstname); ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="lastname">Last Name</label>
                        <input class="form-control" type="text" name="lastname" value="<?php echo e(Auth::user()->lastname); ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="username">Username</label>
                        <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="email">Email</label>
                        <input class="form-control" type="email" value="<?php echo e(Auth::user()->email); ?>" disabled="">
                    </div>


                    <div class="form-group col-md-6">
                        <label for="password">Password</label>
                        <input class="form-control" placeholder="Leave Blank if dont want to change" type="password" name="password">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Profile Image</label>
                        <label class="form-control upload-btn">
                            <i class="fa fa-upload"></i> Upload <input type="file" name="image">
                            <img src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>" class="img-upload"
                                 alt="<?php echo e(Auth::user()->name); ?>">
                        </label>
                    </div>


                    <div class="form-group col-md-6">
                        <input type="submit" class="button" value="Save">
                    </div>
                </div>
            </form>

        </div>

    </div>
    <div class="clearfix"></div>
</section>


<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH E:\laragon\www\helpyea\resources\views/profile.blade.php ENDPATH**/ ?>