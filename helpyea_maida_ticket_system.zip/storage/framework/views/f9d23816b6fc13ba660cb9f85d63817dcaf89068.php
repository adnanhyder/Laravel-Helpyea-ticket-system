<?php echo $__env->make('includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header starting-->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Header ending-->
<?php echo $__env->make('includes.breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="post-section aboutus">
    <div class="container">
        <div class="sidebar-content ml-0 mr-0  mt-5 mb-5 ">
            <form action="/searchfaq" method="get">
                <?php echo e(csrf_field()); ?>

                <div class="input-group">
                    <input type="text" required="required" class="form-control"
                           placeholder="Search for your question..."
                           name="search" <?php if(isset($_GET['search'])): ?> value="<?php echo e($_GET['search']); ?>"
                           <?php endif; ?> aria-label="Search for...">
                    <span class="input-group-btn">
                    <button type="submit" class="btn btn-secondary btn-search" type="button">
                      <span class="fa fa-search"></span>
                    </button>
                  </span>
                </div>
            </form>
        </div>
        <div class="radom">
            <div class="row">
                <?php if(isset($serachfaq)): ?>
                    <?php if(count($serachfaq) > 0): ?>
                        <div class="col-lg-12">

                            <h5>Search Results :</h5>
                        </div>
                        <?php $__currentLoopData = $serachfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <a href="<?php echo e($single->slug); ?>" class="single_faq">
                                    <h5>
                                        <?php echo e($single->title); ?> </h5>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                        <div class="col-lg-12">

                            <h5>No result Found </h5>
                        </div>

                    <?php endif; ?>
                <?php endif; ?>

            <!-- Heading Text  -->
                <div class="col-lg-12 ">
                    <div class="area-title pt-sm-5 pb-5">
                        <div class="content">
                            <h2 class="text-center  logo-green">Frequently Asked Question</h2>
                            <div class="separate text-black-50"></div>
                            <h3 class="text-center text-black-50">Do You Want to Know</h3>
                        </div>
                    </div>
                </div>
                <?php if(!empty($faqs)): ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-6">
                            <a href="<?php echo e($single->slug); ?>" class="single_faq">
                                <h5>
                                    <?php echo e($single->title); ?> </h5>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class=" ml-3 mt-5 mb-5 mr-5">
                        <?php echo e($faqs->onEachSide(5)->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>


    </div>
</div>

<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/faq.blade.php ENDPATH**/ ?>