<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<div class="content  p-1 p-lg-5 p-md-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <?php if(Auth::user()->roles == "admin"): ?>

                    <div class="card ">
                        <div class="card-body p-0 mb-5">
                            <div class="list-replies reply-form">
                                <form method="post" action="/assignManger">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="id" value="<?php echo e(base64_encode($id)); ?>">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label class="d-block p-0 col-lg-12">Assign Manager <span
                                                        class="font-weight-lighter float-right">Previous Assigned:  <?php echo e($tickets_assigned_user_name->name); ?> </span></label>
                                            <select class="form-control" name="assigned_user"
                                                    <?php if($tickets_status != "open"): ?> readonly <?php endif; ?> autocomplete="off">
                                                <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($tickets_assigned_user == $single->id): ?> selected="selected"
                                                            <?php endif; ?> value="<?php echo e($single->id); ?>"> <?php echo e($single->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="d-block p-0 col-lg-12">Assign Department <span
                                                        class="font-weight-lighter float-right">Previous Assigned:  <?php echo e($ticket_department_name->department_name); ?> </span></label>
                                            <select class="form-control" name="department"
                                                    <?php if($tickets_status != "open"): ?> readonly <?php endif; ?> autocomplete="off">
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($ticket_department_name->id == $single->id): ?> selected="selected"
                                                            <?php endif; ?> value="<?php echo e($single->id); ?>"> <?php echo e($single->department_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <?php if($tickets_status != "open"): ?>

                                            <?php else: ?>
                                                <input type="submit" class="button" value="Save">
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="card ">
                    <div class="card-header border-transparent">
                        <h3 class="card-title"><b>Ticket: </b><?php echo e($tickets_subject); ?></h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>

                        </div>
                    </div>


                    <!-- /.card-header -->


                    <div class="card-body p-0">


                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="reply-block">
                                <div class="ticket-user">

                                    <img id="1357" class="img-circle img-responsive" alt="Adnanhyder"
                                         src="<?php echo e(asset('img/user/').'/'.$single->submitted_userdata_picture); ?>">
                                </div>
                                <div class="ticket-msg">
                                    <div class="ticket-user-det">
                                        <b><?php echo e($single->submitted_userdata_name); ?></b> <span
                                                class="float-right"><?php echo e($single->created_at); ?></span>
                                    </div>
                                    <p><?php echo e($single->tickets_message); ?> </p>
                                    <?php if($single->ticket_attachment != ""): ?>
                                        <p>Attachment</p>
                                        <p><img src="<?php echo e(asset('img/tickets/').'/'.$single->ticket_attachment); ?>"
                                                class="d-block img-thumbnail"></p>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php if(Auth::user()->id == $tickets_assigned_user || Auth::user()->roles == "admin" && $tickets_status == "open"): ?>

                        <div class="list-replies reply-form">
                            <form method="post" action="/addticket" autocomplete="off" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e(base64_encode($id)); ?>">
                                <input type="hidden" name="tickets_assigned_user"
                                       value="<?php echo e(base64_encode($tickets_assigned_user)); ?>">

                                <div class="form-group">
                                    <label for="message">Provide description <span
                                                class="required-field">*</span></label>
                                    <textarea class="form-control unsetheigth" rows="4" name="message"
                                              value=""></textarea>

                                </div>
                                <div class="form-group">
                                    <label for="attachement"> Attachment</label>
                                    <div class="btn btn-attached">
                                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                                        <input name="attachment" type="file">
                                        Add file .png/.jpg/.jpeg
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="button" value="Save">
                                </div>

                            </form>


                        </div>
                        <!-- /.card-body -->
                    <?php endif; ?>
                </div>
            </div>
            <!-- ./col -->
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/ticket.blade.php ENDPATH**/ ?>