Hello,


Status :
<?php echo e($content->status); ?>



Message :
<?php echo e($content->message); ?>


Thankyou

<img src="<?php echo e($content->footerlogo); ?>">


Thank You,


<?php /**PATH /home/helpyea/public_html/resources/views/mail/notification_plain.blade.php ENDPATH**/ ?>