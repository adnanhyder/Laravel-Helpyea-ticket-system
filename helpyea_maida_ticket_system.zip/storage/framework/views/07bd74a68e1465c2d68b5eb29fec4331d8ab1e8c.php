<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php
    $settingobject =  json_decode($settings) ;

?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- favicon icon -->
    <link rel="icon" href="<?php if(isset($settingobject->favicon)): ?><?php echo e(asset('img').'/'.$settingobject->favicon); ?><?php endif; ?>"
          type="image/gif" sizes="16x16">
    <title><?php if(isset($settingobject->title)): ?><?php echo e($settingobject->title); ?><?php else: ?> Helpyea <?php endif; ?></title>


    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.css')); ?>">
    <!-- admin style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

    <!-- admin responsive style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive-admin.css')); ?>">
    <!-- Google Font: Popins -->

    
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<?php /**PATH /home/helpyea/public_html/resources/views/admin/includes/htmlhead.blade.php ENDPATH**/ ?>