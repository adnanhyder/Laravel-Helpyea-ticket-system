<?php echo $__env->make('admin.includes.htmlhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main content -->
    <div class="content  p-1 p-lg-5 p-md-5">
        <div class="container-fluid">
            <div class="row">
                <div class="panel panel-default card col-lg-12">
                    <div class="panel-heading pt-4 pl-4">
                        <h3 class="panel-title">Add/Edit Page/Faq</h3>
                    </div>
                    <div class="panel-body p-4">
                        <form  class="form-horizontal" method="post" enctype="multipart/form-data" action="/submitfaq">
                            <?php echo e(csrf_field()); ?>


                            <div class="col-sm-10">
                                <?php if(!empty($faq->id)): ?>
                                    <input type="hidden" name="id" value="<?php echo e($faq->id); ?>">

                                <?php endif; ?>
                                <div class="form-group">
                                    <label class="control-label" for="field-1">Title <span class="required">*</span></label>

                                    <?php if(!empty($faq->id)): ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="Title"
                                               name="title"
                                               value="<?php echo e($faq->title); ?>">
                                        <label class="control-label" for="field-1">Select Identity </label>

                                        <select name="identity" class="form-control" autocomplete="off">
                                            <option <?php if($faq->identity == "faq"): ?> selected="selected" <?php endif; ?> value="faq" >FAQ</option>
                                            <option <?php if($faq->identity == "page"): ?> selected="selected" <?php endif; ?> value="page">Page</option>
                                            <option <?php if($faq->identity == "homepagetagline1"): ?> selected="selected" <?php endif; ?> value="homepagetagline1">HomePage Tagline 1</option>
                                            <option <?php if($faq->identity == "homepagetagline2"): ?> selected="selected" <?php endif; ?> value="homepagetagline2">HomePage Tagline 2</option>

                                        </select>
                                        <label class="control-label" for="field-1">Description <span class="required">*</span></label>

                                        <textarea type="text" id="field-1" class="form-control unsetheigth"
                                                  rows="15"    name="description"><?php echo e($faq->description); ?></textarea>


                                    <?php else: ?>
                                        <input type="text" id="field-1" class="form-control" placeholder="Title"
                                               name="title"
                                               value="">
                                        <label class="control-label" for="field-1">Select Identity </label>

                                        <select name="identity" class="form-control">
                                            <option value="faq" >FAQ</option>
                                            <option value="page">Page</option>
                                            <option value="homepagetagline1">HomePage Tagline 1</option>
                                            <option value="homepagetagline2">HomePage Tagline 2</option>

                                        </select>
                                        <label class="control-label" for="field-1">Description <span class="required">*</span></label>

                                        <textarea type="text" id="field-1" class="form-control unsetheigth"
                                                  rows="15"    name="description"
                                                  value=""></textarea>
                                    <?php endif; ?>

                                </div>


                                <div class="form-group">
                                    <label class="col-sm-2 control-label"></label>

                                    <div class="col-sm-10">
                                        <input type="submit" class="btn btn-secondary " name="submit" value="Save">
                                        <a href="<?php echo e(route('department')); ?>"
                                           class="btn btn-danger">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\helpyea\resources\views/admin/addfaq.blade.php ENDPATH**/ ?>