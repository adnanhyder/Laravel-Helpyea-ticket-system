<header>
    <!--Header top bar starting-->
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-10">
                    <div class="header-top-info-list d-none d-md-block">
                        <!-- header top list time -->
                        <?php
                            $settingobject =  json_decode($settings) ;

                        ?>
                        <ul>
                            <li><i class="fas fa-envelope"></i> <?php echo e($settingobject->admin_email); ?></li>
                            <li><i class="fas fa-mobile-alt"></i> <?php echo e($settingobject->phone); ?></li>
                            <li><i class="fas fa-clock"></i> <?php echo e($settingobject->time); ?></li>
                        </ul>
                    </div> <!-- header top list time end-->
                </div>
                <div class="col-lg-3 col-md-2">
                    <div class="header-top-social-icons text-center text-md-right">
                        <!-- header top social icons start-->
                        <ul>
                            <li><a href="<?php echo e($settingobject->facebook); ?>"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="<?php echo e($settingobject->twitter); ?>"><i class="fab fa-twitter-square"></i></a></li>

                        </ul>
                    </div> <!-- header top social icons -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    <!--Header top bar ending-->
    <!-- header menu and logo starting -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="navigation">
                    <nav class="navbar navbar-expand-lg   justify-content-between nav-color p-0">
                        <div class="navbar-header ">
                            <!--logo start-->
                            <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" class="max-width-60px">
                            </a>
                            <!--end logo-->
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent"
                                    aria-controls="navbarSupportedContent" aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div> <!--nav bar header ending -->
                        <!--menu start-->
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="nav navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('index')); ?>">Home
                                        <span class="sr-only">(current)</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('faq')); ?>">Knowledge Base</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
                                </li>
                                <?php if(auth()->guard()->guest()): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                                    </li>
                                <?php else: ?>
                                    <?php if(Auth::user()->roles == "normal"): ?>
                                        <li class="nav-item">
                                            <a class="nav-link " href="<?php echo e(route('home')); ?>">Tickets</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link " href="<?php echo e(route('submit')); ?>">Submit Ticket</a>
                                        </li>
                                    <?php else: ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('admin')); ?>">Dashboard</a>
                                        </li>

                                    <?php endif; ?>
                                    <li class="nav-item d-sm-block d-md-block d-lg-none">
                                        <div class="dropdown " style="position: relative;">
                                            <a class="nav-link" href="#" id="user_profile_dropdown"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span
                                                        class="profile_pic_menu"><img
                                                            src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>"></span>
                                                <span><?php echo e(Auth::user()->name); ?></span> </a>
                                            <div class="dropdown-menu adjust_menu border pt-4 pb-4 radius-11"
                                                 aria-labelledby="user_profile_dropdown" style="position: absolute;">
                                                <div class="more-menu-caret">
                                                    <div class="more-menu-caret-outer"></div>
                                                    <div class="more-menu-caret-inner"></div>
                                                </div>
                                                <div class="row pl-4 pr-4">
                                                    <div class="col-md-auto">
                                                        <img src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>"
                                                             alt="User Image" class="rounded-circle" width="73px"
                                                             height="73px">
                                                    </div>
                                                    <div class="col-sm user_menu">
                                                        <strong><?php echo e(Auth::user()->name); ?></strong>
                                                        <p><?php echo e(Auth::user()->email); ?></p>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Sign Out')); ?></a>
                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                      style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="nav-item d-none d-lg-block position-relative">
                                        <a class="nav-link" href="#" id="user_profile_dropdown"><span
                                                    class="profile_pic_menu"><img
                                                        src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>"></span>
                                            <span class="uname_top"><?php echo e(Auth::user()->name); ?></span> </a>

                                        <div class="dropdown dropleft  fade-out">
                                            <div class=" adjust_menu border pt-4 pb-4 radius-11"
                                                 aria-labelledby="user_profile_dropdown">
                                                <div class="more-menu-caret">
                                                    <div class="more-menu-caret-outer"></div>
                                                    <div class="more-menu-caret-inner"></div>
                                                </div>
                                                <div class="row pl-4 pr-4">
                                                    <div class="col-md-auto">
                                                        <img src="<?php echo e(asset('img/user').'/'.Auth::user()->profile_pic); ?>"
                                                             alt="User Image" class="rounded-circle" width="73px"
                                                             height="73px">
                                                    </div>
                                                    <div class="col-sm user_menu">
                                                        <strong><?php echo e(Auth::user()->name); ?></strong>
                                                        <p><?php echo e(Auth::user()->email); ?></p>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>

                                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Sign Out')); ?></a>
                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                      style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </div>
                                        </div>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!--menu end-->
                    </nav> <!--nav ending -->
                </div>
            </div>
        </div>
    </div>
    <!-- header menu and logo ending -->
</header>
<?php /**PATH /home/helpyea/public_html/resources/views/includes/header.blade.php ENDPATH**/ ?>