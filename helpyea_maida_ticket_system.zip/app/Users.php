<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    //
    protected $fillable = [
        'name', 'email', 'password', 'roles', 'firstname', 'lastname', 'status','profile_pic',
    ];
}
