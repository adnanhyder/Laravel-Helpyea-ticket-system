<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Departments extends Model
{
    //
    protected $fillable = [
        'department_name', 'ticket_id',
    ];

}
