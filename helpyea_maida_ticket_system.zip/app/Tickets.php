<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tickets extends Model
{
    //
    protected $fillable = [
        'submitted_user_id', 'assigned_user_id', 'parent_ticket_id', 'ticket_subject', 'ticket_detail', 'ticket_status', 'ticket_attachment' ,'department_id',
    ];
}
