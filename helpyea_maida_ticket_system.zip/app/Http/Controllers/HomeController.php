<?php

namespace App\Http\Controllers;

use App\Departments;
use App\Faqs;
use App\Setting;
use App\Users;
use App\Tickets;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Psy\Util\Str;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('inactive');


    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if (Auth::user()->roles == "manager") {
            return redirect()->back();
        }
        $tickets = Tickets::orderBy('id', 'desc')->where('submitted_user_id', '=', Auth::user()->id)->where('parent_ticket_id', '=', 0)->Paginate(10);
        $userdata = Users::all();
        return view('home')->with('tickets', $tickets)->with('users', $userdata)->with("settings", json_encode($this->returnSettings()))
            ->with('menu', $this->footer_menu());
    }

    public function ticket($id)
    {
        if (Auth::user()->roles == "manager") {
            return redirect()->back();
        }
        $tickets = Tickets::orderBy('id', 'asc')->where('id', '=', $id)->orwhere('parent_ticket_id', '=', $id)->get();
        $tickets_detail_parent = Tickets::where('id', '=', $id)->first();
        $tickets_subject = $tickets_detail_parent->ticket_subject;
        $tickets_assigned_user = $tickets_detail_parent->assigned_user_id;
        $tickets_department_id = $tickets_detail_parent->department_id;
        $ticket_department_name = Departments::find($tickets_department_id);

        $tickets_assigned_user_name = Users::find($tickets_assigned_user);
        foreach ($tickets as $single):

            $submitted_userdata = Users::find($single->submitted_user_id);
            $assigned_userdata = Users::find($single->assigned_user_id);
            $id = $id;

            $data[] = [
                'id' => $single->id,
                'submitted_userdata_name' => $submitted_userdata->name,
                'submitted_userdata_picture' => $submitted_userdata->profile_pic,
                'assigned_userdata' => $assigned_userdata->name,
                'assigned_userdata_picture' => $assigned_userdata->profile_pic,
                'tickets_message' => $single->ticket_detail,
                'ticket_attachment' => $single->ticket_attachment,
                'created_at' => $single->created_at->isoFormat('LLL'),
                'updated_at' => $single->updated_at->isoFormat('LLL'),
            ];

        endforeach;

        $data = json_decode(json_encode($data), FALSE);
        return view('ticket')->with('data', $data)->with('tickets_subject', $tickets_subject)->with('id', $id)
            ->with('tickets_assigned_user', $tickets_assigned_user)->with('tickets_assigned_user_name', $tickets_assigned_user_name)
            ->with('ticket_department_name', $ticket_department_name)->with("settings", json_encode($this->returnSettings()))
            ->with('menu', $this->footer_menu());
    }

    public function submitTicket()
    {
        if (Auth::user()->roles == "manager") {
            return redirect()->back();
        }
        $departments = Departments::orderBy('id', 'desc')->get();
        return view('submitTicket')->with('departments', $departments)->with("settings", json_encode($this->returnSettings()))->with('menu', $this->footer_menu());
    }

    public function profile()
    {

        return view('profile')->with("settings", json_encode($this->returnSettings()))->with('menu', $this->footer_menu());
    }

    public function admin()
    {

        $ticketstotal = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->get();
        $ticketstotal = $ticketstotal->count();
        $departmenttotal = Departments::orderBy('id', 'desc')->get();
        $departmenttotal = $departmenttotal->count();
        $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->Paginate(5);
        $users = Users::all();
        return view('admin/dashboard')->with("settings", json_encode($this->returnSettings()))
            ->with('users', $users)->with('tickets', $tickets)->with('ticketstotal', $ticketstotal)->with('departmenttotal', $departmenttotal)->with('dashboard_active', "active");
    }

    public function users()
    {
        $users = Users::all();

        return view('admin/users')->with("settings", json_encode($this->returnSettings()))
            ->with('users', $users)->with('alluser_active', "active");
    }

    public function addUser($id = "")
    {
        $userdata = Users::find($id);

        return view('admin/adduser')->with("settings", json_encode($this->returnSettings()))
            ->with('user', $userdata);
    }

    public function showTickets()
    {
        if (Auth::user()->roles == "normal") {
            return redirect('/home');
        } elseif (Auth::user()->roles == "manager") {
            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->where('assigned_user_id', '=', Auth::user()->id)->Paginate(20);
            return view('admin/tickets')->with("settings", json_encode($this->returnSettings()))
                ->with('tickets', $tickets)->with('menuopen', 'menu-open')->with('allticket', 'active');
        } else {
            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->Paginate(20);
            return view('admin/tickets')->with("settings", json_encode($this->returnSettings()))
                ->with('tickets', $tickets)->with('menuopen', 'menu-open')->with('allticket', 'active');
        }


    }

    public function showTicketsOpen()
    {
        if (Auth::user()->roles == "normal") {
            return redirect('/home');
        } elseif (Auth::user()->roles == "manager") {

            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->where('ticket_status', "=", "open")->where('assigned_user_id', '=', Auth::user()->id)->Paginate(20);
            return view('admin/tickets')->with("settings", json_encode($this->returnSettings()))
                ->with('tickets', $tickets)->with('menuopen', 'menu-open')->with('ticketopen', 'active');
        } else
            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->where('ticket_status', "=", "open")->Paginate(20);
        return view('admin/tickets')->with("settings", json_encode($this->returnSettings()))
            ->with('tickets', $tickets)->with('menuopen', 'menu-open')->with('ticketopen', 'active');
    }

    public function showTicketsClose()
    {
        if (Auth::user()->roles == "normal") {
            return redirect('/home');
        } elseif (Auth::user()->roles == "manager") {
            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->where('ticket_status', "=", "closed")->where('assigned_user_id', '=', Auth::user()->id)->Paginate(20);
            return view('admin/tickets')->with("settings", json_encode($this->returnSettings()))
                ->with('tickets', $tickets)->with('menuopen', 'menu-open')->with('ticketclose', 'active');
        } else {
            $tickets = Tickets::orderBy('id', 'desc')->where('parent_ticket_id', '=', 0)->where('ticket_status', "=", "closed")->Paginate(20);
            return view('admin/tickets')
                ->with('tickets', $tickets)->with("settings", json_encode($this->returnSettings()))
                ->with('menuopen', 'menu-open')->with('ticketclose', 'active');
        }
    }

    public function showSingleTicket($id)
    {
        if (Auth::user()->roles == "normal") {
            return redirect('/home');
        }
        $tickets = Tickets::orderBy('id', 'asc')->where('id', '=', $id)->orwhere('parent_ticket_id', '=', $id)->get();
        $tickets_detail_parent = Tickets::where('id', '=', $id)->first();
        $tickets_subject = $tickets_detail_parent->ticket_subject;
        $tickets_status = $tickets_detail_parent->ticket_status;
        $tickets_assigned_user = $tickets_detail_parent->assigned_user_id;
        $tickets_assigned_user_name = Users::find($tickets_assigned_user);
        $tickets_department_id = $tickets_detail_parent->department_id;
        $ticket_department_name = Departments::find($tickets_department_id);

        foreach ($tickets as $single):

            $submitted_userdata = Users::find($single->submitted_user_id);
            $assigned_userdata = Users::find($single->assigned_user_id);
            $id = $id;

            $data[] = [
                'id' => $single->id,
                'submitted_userdata_name' => $submitted_userdata->name,
                'submitted_userdata_picture' => $submitted_userdata->profile_pic,
                'assigned_userdata' => $assigned_userdata->name,
                'assigned_userdata_picture' => $assigned_userdata->profile_pic,
                'tickets_message' => $single->ticket_detail,
                'ticket_attachment' => $single->ticket_attachment,
                'created_at' => $single->created_at->isoFormat('LLL'),
                'updated_at' => $single->updated_at->isoFormat('LLL'),
            ];

        endforeach;
        $departments = Departments::orderBy('id', 'desc')->get();
        $managers = Users::orderBy('id', 'asc')->where('roles', '=', 'manager')->get();
        $data = json_decode(json_encode($data), FALSE);
        return view('admin/ticket')->with('data', $data)->with('tickets_subject', $tickets_subject)->with('id', $id)
            ->with('tickets_assigned_user', $tickets_assigned_user)->with('tickets_assigned_user_name', $tickets_assigned_user_name)
            ->with('departments', $departments)->with('managers', $managers)
            ->with('ticket_department_name', $ticket_department_name)
            ->with("settings", json_encode($this->returnSettings()))
            ->with('tickets_status',$tickets_status);
    }


    public function departments()
    {
        $department = Departments::all();

        return view('admin/department')->with("settings", json_encode($this->returnSettings()))
            ->with('departments', $department)->with('department_active', 'active');
    }

    public function addDepartment($id = "")
    {
        $department = Departments::find($id);

        return view('admin/adddepartment')->with("settings", json_encode($this->returnSettings()))
            ->with('department', $department);
    }


    public function siteSettings()
    {
        $settings = Setting::orderBy('id', 'desc')->where("setting_name", "=", "maida_site_settings")->first();

        if (isset($settings->id)) {
            $id = $settings->id;
            $settings = unserialize($settings->setting_value);

        } else {
            $settings = "";
            $id = "";
        }


        return view('admin/sitesettings')->with("settings", json_encode($this->returnSettings()))->with('id', $id)->with('setting_active','active')->with('settingmenuopen',"menu-open");
    }

    public function welcome()
    {
      return view('welcome')->with("settings", json_encode($this->returnSettings()));
    }

    public function returnSettings(){
        $settings = Setting::orderBy('id', 'desc')->where("setting_name", "=", "maida_site_settings")->first();

        if (isset($settings->id)) {
            $settings = unserialize($settings->setting_value);

        } else {
            $settings = [
                'facebook' => "https://www.facebook.com/Adnanhyder123",
                'twitter' => "https://www.facebook.com/Adnanhyder123",
                'phone' => "+12345689456",
                'time' => "9AM to 5PM (Mon - Fri)",
                'admin_email' => "maidathemes@gmail.com",
                'copyrights' => "Copyright 2019 Maida. All Rights Reserved.",
                'title' => "helpyea",
                'logo' => "logo.png",
                'favicon' => "fav.png",
            ];

        }
        return $settings;
    }


    public function faqs()
    {
        $faqs = Faqs::orderBy('id', 'desc')->Paginate(20);
        return view('admin.faqs')->with("settings", json_encode($this->returnSettings()))
            ->with("faqs_active",'active')->with("faqs",$faqs)->with('settingmenuopen',"menu-open");
    }
    public function addFaq($id = "")
    {
        $faq = Faqs::find($id);

        return view('admin.addfaq')->with("settings", json_encode($this->returnSettings()))
            ->with("faqs_active",'active')->with("faq",$faq)->with('settingmenuopen',"menu-open");
    }

    public function showSingleFaq($id)
    {
        if (Auth::user()->roles == "normal") {
            return redirect('/home');
        }
        $faq_detail = Faqs::where('id', '=', $id)->first();

        return view('admin/faq')->with("settings", json_encode($this->returnSettings()))
            ->with('faq_detail', $faq_detail)->with('settingmenuopen',"menu-open");
    }
    public function footer_menu()
    {
        $page = Faqs::OrderBy("id", "desc")->where('identity', "=", "page")->get();
        $data = [];

        foreach ($page as $single) {
            $data[] = [
                "id" => $single->id,
                "title" => $single->title,
                "slug" => $single->slug,
            ];
        }
        return json_encode($data);
    }


}
