<?php

namespace App\Http\Controllers;

use App\Departments;
use App\Faqs;
use App\Jobs\SendEmailJob;
use App\Mail\TicketNotifiction;
use App\Setting;
use App\Tickets;
use App\Users;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;


class DataUserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('inactive');


    }


    public function emailNotifiction($content)
    {

        $submitted_user_email = Users::Where("id", "=", $content['submitted_user_id'])->first();
        $submitted_user_email = $submitted_user_email->email;

        $assigned_user_email = Users::Where("id", "=", $content['assigned_user_id'])->first();
        $assigned_user_email = $assigned_user_email->email;


        $obj = new \stdClass();
        $obj->message = $content['submitted_reply'];
        $obj->email = $submitted_user_email;
        $obj->footerlogo = asset('img') . '/logo.png';
        $obj->status = $content['status'];

        dispatch(new SendEmailJob($obj));
        //Mail::to($submitted_user_email)->send(new TicketNotifiction($obj));


        $obj = new \stdClass();
        $obj->message = $content['assigned_reply'];
        $obj->email = $assigned_user_email;
        $obj->footerlogo = asset('img') . '/logo.png';
        $obj->status = $content['status'];
        dispatch(new SendEmailJob($obj));
        //Mail::to($assigned_user_email)->send(new TicketNotifiction($obj));
        return true;
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if (empty($request->id)) {
            $this->validate($request, [
                'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);
            $this->validate($request, [
                'email' => 'required|unique:users,email',
            ]);
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $nameofimage = time() . '_' . $request->name . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('/img/user');
                $image->move($destinationPath, $nameofimage);
                Users::create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => bcrypt($request->password),
                    'roles' => $request->user_role,
                    'firstname' => $request->firstname,
                    'lastname' => $request->lastname,
                    'status' => $request->status,
                    'profile_pic' => $nameofimage,
                ]);

                return back()->with('success', 'User Created Successfully');
            }
        } else {
            $this->validate($request, [
                'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $nameofimage = time() . '_' . $request->name . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('/img/user');
                $image->move($destinationPath, $nameofimage);
                if (!empty($request->password)) {
                    Users::updateOrCreate(
                        ['id' => $request->id,],
                        ['name' => $request->name,
                            'email' => $request->email,
                            'password' => bcrypt($request->password),
                            'roles' => $request->user_role,
                            'firstname' => $request->firstname,
                            'lastname' => $request->lastname,
                            'status' => $request->status,
                            'profile_pic' => $nameofimage,
                        ]);
                } else {
                    Users::updateOrCreate(
                        ['id' => $request->id],
                        ['name' => $request->name,
                            'email' => $request->email,
                            'roles' => $request->user_role,
                            'firstname' => $request->firstname,
                            'lastname' => $request->lastname,
                            'status' => $request->status,
                            'profile_pic' => $nameofimage,
                        ]);

                }
                return back()->with('success', 'User updated Successfully');
            } else {
                if (!empty($request->password)) {
                    Users::updateOrCreate(
                        ['id' => $request->id,],
                        ['name' => $request->name,
                            'email' => $request->email,
                            'password' => bcrypt($request->password),
                            'roles' => $request->user_role,
                            'firstname' => $request->firstname,
                            'lastname' => $request->lastname,
                            'status' => $request->status,
                        ]);
                } else {
                    Users::updateOrCreate(
                        ['id' => $request->id],
                        ['name' => $request->name,
                            'email' => $request->email,
                            'roles' => $request->user_role,
                            'firstname' => $request->firstname,
                            'lastname' => $request->lastname,
                            'status' => $request->status,
                        ]);
                }
                return back()->with('success', 'User updated Successfully');
            }
        }

    }

    public function storeProfile(Request $request)
    {

        $this->validate($request, [
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $nameofimage = time() . '_' . $request->name . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/img/user');
            $image->move($destinationPath, $nameofimage);
            if (!empty($request->password)) {
                Users::updateOrCreate(
                    ['id' => base64_decode($request->encodedstring)],
                    ['name' => $request->name,
                        'password' => bcrypt($request->password),
                        'firstname' => $request->firstname,
                        'lastname' => $request->lastname,
                        'profile_pic' => $nameofimage,
                    ]);
            } else {
                Users::updateOrCreate(
                    ['id' => base64_decode($request->encodedstring)],
                    ['name' => $request->name,
                        'firstname' => $request->firstname,
                        'lastname' => $request->lastname,
                        'profile_pic' => $nameofimage,
                    ]);

            }
            return back()->with('success', 'User updated Successfully');
        } else {
            if (!empty($request->password)) {
                Users::updateOrCreate(
                    ['id' => base64_decode($request->encodedstring)],
                    ['name' => $request->name,
                        'password' => bcrypt($request->password),
                        'firstname' => $request->firstname,
                        'lastname' => $request->lastname,
                    ]);
            } else {
                Users::updateOrCreate(
                    ['id' => base64_decode($request->encodedstring)],
                    ['name' => $request->name,
                        'firstname' => $request->firstname,
                        'lastname' => $request->lastname,
                    ]);
            }
            return back()->with('success', 'User updated Successfully');
        }


    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $userdata = Users::find($id);
        Users::find($id)->delete();
        $profile_pic = $userdata->profile_pic;
        if (!empty($profile_pic)) {
            $file_path = base_path() . '/public/img/user/' . $profile_pic;
            unlink($file_path);
        }
        return back()->with('success', 'User Deleted Successfully');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function addTicket(Request $request)
    {
        $useradmin = Users::orderBy('id', 'asc')->where('roles', '=', 'admin')->where('status', '=', 'active')->first();


        $this->validate($request, [
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);


        if (empty($request->id)) {
            if ($request->hasFile('attachment')) {
                $image = $request->file('attachment');
                $nameofimage = time() . '_id_' . Auth::user()->id . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('/img/tickets');
                $image->move($destinationPath, $nameofimage);
                Tickets::create([
                    'parent_ticket_id' => 0,
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => $useradmin->id,
                    'ticket_subject' => $request->subject,
                    'ticket_detail' => $request->message,
                    'department_id' => $request->department,
                    'ticket_status' => "open",
                    'ticket_attachment' => $nameofimage,
                ]);

                $data_mail = [
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => $useradmin->id,
                    'submitted_reply' => "You have created a new Ticket",
                    'assigned_reply' => "A Ticket Has been assigned to you",
                    "status" => "Created",
                ];
                $this->emailNotifiction($data_mail);

                return redirect('home')->with('success', 'Ticket Created Successfully');
            } else {
                Tickets::create([
                    'parent_ticket_id' => 0,
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => $useradmin->id,
                    'ticket_subject' => $request->subject,
                    'department_id' => $request->department,
                    'ticket_detail' => $request->message,
                    'ticket_status' => "open",
                ]);
                $data_mail = [
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => $useradmin->id,
                    'submitted_reply' => "You have created a new Ticket",
                    'assigned_reply' => "A Ticket Has been assigned to you",
                    "status" => "Created",
                ];
                $this->emailNotifiction($data_mail);
                return redirect('home')->with('success', 'Ticket Created Successfully');


            }
        } else {
            if ($request->hasFile('attachment')) {
                $image = $request->file('attachment');
                $nameofimage = time() . '_Ticketid_' . base64_decode($request->id) . '.' . $image->getClientOriginalExtension();
                $destinationPath = public_path('/img/tickets');
                $image->move($destinationPath, $nameofimage);
                Tickets::create([
                    'parent_ticket_id' => base64_decode($request->id),
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => base64_decode($request->tickets_assigned_user),
                    'ticket_subject' => '',
                    'ticket_detail' => $request->message,
                    'ticket_status' => "",
                    'ticket_attachment' => $nameofimage,
                ]);
                $data_mail = [
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => base64_decode($request->tickets_assigned_user),
                    'submitted_reply' => "There is new message on Ticket #" . base64_decode($request->id),
                    'assigned_reply' => "There is new message on Ticket #" . base64_decode($request->id),
                    "status" => "Updated",
                ];
                $this->emailNotifiction($data_mail);
                return back()->with('success', 'Message Sent Successfully');
            } else {
                Tickets::create([
                    'parent_ticket_id' => base64_decode($request->id),
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => base64_decode($request->tickets_assigned_user),
                    'ticket_subject' => '',
                    'ticket_detail' => $request->message,
                    'ticket_status' => "",
                ]);
                $data_mail = [
                    'submitted_user_id' => Auth::user()->id,
                    'assigned_user_id' => base64_decode($request->tickets_assigned_user),
                    'submitted_reply' => "There is new message on Ticket #" . base64_decode($request->id) ,
                    'assigned_reply' => "There is new message on Ticket #". base64_decode($request->id) ,
                    "status" => "Updated",
                ];
                $this->emailNotifiction($data_mail);
                return back()->with('success', 'Message Sent Successfully');
            }
        }

    }

    public function departmentStore(Request $request)
    {

        if (empty($request->id)) {

            $this->validate($request, [
                'name' => 'required',
            ]);
            Departments::create([
                'department_name' => $request->name,
            ]);
            return back()->with('success', 'Department Created Successfully');

        } else {
            Departments::updateOrCreate(
                [
                    'id' => $request->id,
                ],
                [
                    'department_name' => $request->name,
                ]);
            return back()->with('success', 'Department updated Successfully');
        }
    }


    public function destroyDepartment($id)
    {
        //
        Departments::find($id)->delete();


        return back()->with('success', 'Department Deleted Successfully');
    }


    public function assignManger(Request $request)
    {

        $tickets_detail_parent = Tickets::where('id', '=', base64_decode($request->id))->first();
        $tickets_submitted_user = $tickets_detail_parent->submitted_user_id;
        Tickets::updateOrCreate(
            [
                'id' => base64_decode($request->id),
            ],
            [
                'assigned_user_id' => $request->assigned_user,
                'department_id' => $request->department,
            ]);

        $data_mail = [
            'submitted_user_id' => $tickets_submitted_user,
            'assigned_user_id' => $request->assigned_user,
            'submitted_reply' => "A Manger is assigned to Your Ticket",
            'assigned_reply' => "A ticked has been assigned to you",
            "status" => "Updated",
        ];
        $this->emailNotifiction($data_mail);
        return back()->with('success', 'Department/Manager updated Successfully');
    }

    public function deleteTicket($id)
    {
        //
        Tickets::find($id)->delete();


        return back()->with('success', 'Ticket Deleted Successfully');
    }

    public function closeTicket($id)
    {
        $tickets_detail_parent = Tickets::where('id', '=', $id)->first();
        $tickets_submitted_user = $tickets_detail_parent->submitted_user_id;
        $tickets_assigned_user = $tickets_detail_parent->assigned_user_id;


        Tickets::updateOrCreate(
            [
                'id' => $id,
            ],
            [
                'ticket_status' => "closed",

            ]);

        $data_mail = [
            'submitted_user_id' => $tickets_submitted_user,
            'assigned_user_id' => $tickets_assigned_user,
            'submitted_reply' => "Your Ticket #".$id. " Has been Closed",
            'assigned_reply' => "Ticket #".$id.' Has been Closed',
            "status" => "Updated",
        ];
        $this->emailNotifiction($data_mail);
        return back()->with('success', 'Ticket #' . $id . ' Closed Successfully');
    }

    public function reopenTicket($id)
    {
        $tickets_detail_parent = Tickets::where('id', '=', $id)->first();
        $tickets_submitted_user = $tickets_detail_parent->submitted_user_id;
        $tickets_assigned_user = $tickets_detail_parent->assigned_user_id;


        Tickets::updateOrCreate(
            [
                'id' => $id,
            ],
            [
                'ticket_status' => "open",

            ]);
        $data_mail = [
            'submitted_user_id' => $tickets_submitted_user,
            'assigned_user_id' => $tickets_assigned_user,
            'submitted_reply' => "Your Ticket #".$id. " Has been Opened Again",
            'assigned_reply' => "Ticket #".$id ." & is Opened Again",
            "status" => "Updated",
        ];
        $this->emailNotifiction($data_mail);
        return back()->with('success', 'Ticket #' . $id . ' Opened Successfully');
    }

    public function siteSettings(Request $request)
    {
        $settings = Setting::orderBy('id', 'desc')->where("setting_name", "=", "maida_site_settings")->first();

        if (isset($settings->id)) {
            $id = $settings->id;
            $settings = unserialize($settings->setting_value);

        } else {
            $settings = "";
            $id = "";
        }


        $this->validate($request, [
            'logo' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'favicon' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        if ($request->hasFile('logo')) {
            $image = $request->file('logo');
            $nameoflogo = 'logo.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/img');
            $image->move($destinationPath, $nameoflogo);
            $data_logo = [

                'logo' => $nameoflogo,
            ];

        } else {
            $nameoflogo = "";
            if (isset($settings['logo'])) {
                $nameoflogo = $settings['logo'];
            }
            $data_logo = [
                'logo' => $nameoflogo,
            ];
        }
        if ($request->hasFile('favicon')) {
            $image = $request->file('favicon');
            $nameoffav = 'fav.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/img');
            $image->move($destinationPath, $nameoffav);
            $data_favicon = [
                'favicon' => $nameoffav,
            ];
        } else {
            $nameoffav = "";
            if (isset($settings['favicon'])) {
                $nameoffav = $settings['favicon'];
            }
            $data_favicon = [
                'favicon' => $nameoffav,
            ];
        }


        $data = [
            'facebook' => $request->facebook,
            'twitter' => $request->twitter,
            'phone' => $request->phone,
            'time' => $request->time,
            'admin_email' => $request->email,
            'title' => $request->title,
            'copyrights' => $request->copyrights,


        ];

        $data = array_merge($data, $data_logo);
        $data = array_merge($data, $data_favicon);


        $data = serialize($data);
        if (!empty($request->id)) {
            Setting::updateOrCreate(
                [
                    'id' => $request->id,
                ],
                [
                    'setting_name' => "maida_site_settings",
                    'setting_value' => $data,

                ]);
        } else {
            Setting::create([
                "setting_name" => "maida_site_settings",
                "setting_value" => $data,
            ]);
        }
        return back()->with('success', 'Data Saved Successfully');

    }


    public function faqStore(Request $request)
    {

        if (empty($request->id)) {

            $this->validate($request, [
                'title' => 'required',
            ]);
            Faqs::create([
                'title' => $request->title,
                'slug' => Str::slug($request->title, "-"),
                'description' => $request->description,
                'identity' => $request->identity,
            ]);
            return back()->with('success', $request->identity . ' Created Successfully');

        } else {
            Faqs::updateOrCreate(
                [
                    'id' => $request->id,
                ],
                [
                    'title' => $request->title,
                    'slug' => Str::slug($request->title, "-"),
                    'description' => $request->description,
                    'identity' => $request->identity,
                ]);
            return back()->with('success', $request->identity . ' updated Successfully');
        }
    }

    public function destroyFaq($id)
    {
        //
        Faqs::find($id)->delete();


        return back()->with('success', '#' . $id . ' Deleted Successfully');
    }

}
