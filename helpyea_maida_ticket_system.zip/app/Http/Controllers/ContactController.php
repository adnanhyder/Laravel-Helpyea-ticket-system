<?php

namespace App\Http\Controllers;

use App\Faqs;
use App\Setting;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    //
    public function __construct()
    {

        //$this->middleware('inactive');


    }

    public function index()
    {
        return view('contact')->with("settings", json_encode($this->returnSettings()))->with('menu', $this->footer_menu())->with("retunmessage" , "");
    }

    public function faq()
    {
        $faqs = Faqs::OrderBy("id", "desc")->where('identity', "=", "faq")->paginate(20);
        return view('faq')->with("settings", json_encode($this->returnSettings()))->with("faqs", $faqs)->with('menu', $this->footer_menu());
    }

    public function searchFaq(Request $request)
    {
        $faqs = Faqs::OrderBy("id", "desc")->where('identity', "=", "faq")->paginate(20);
        $serachfaq = Faqs::OrderBy("id", "desc")->where("title", "LIKE", '%' . $request->search . '%')->get();


        return view('faq')->with("settings", json_encode($this->returnSettings()))->with("faqs", $faqs)->with("serachfaq", $serachfaq)->with('menu', $this->footer_menu());
    }

    public function welcome()
    {
        $faqs = Faqs::OrderBy("id", "desc")->where('identity', "=", "faq")->paginate(20);
        $homepagetagline1 = Faqs::OrderBy("id", "desc")->where('identity', "=", "homepagetagline1")->first();
        $homepagetagline2 = Faqs::OrderBy("id", "desc")->where('identity', "=", "homepagetagline2")->first();

        if(empty($homepagetagline1)){
            $homepagetagline1 = [
                'title'=>"Dummy Text",
                'description' => "Dummy Text",
            ];
            $homepagetagline1 = json_decode(json_encode($homepagetagline1));
        }
        if(empty($homepagetagline2)){
            $homepagetagline2 = [
                'title'=>"Dummy Text",
                'description' => "Dummy Text",
            ];
            $homepagetagline2 = json_decode(json_encode($homepagetagline2));
        }

        return view('welcome')->with("settings", json_encode($this->returnSettings()))->with("faqs", $faqs)->with('tagline1', $homepagetagline1)->with('tagline2', $homepagetagline2)
            ->with('menu', $this->footer_menu());
    }

    public function returnSettings()
    {
        $settings = Setting::orderBy('id', 'desc')->where("setting_name", "=", "maida_site_settings")->first();

        if (isset($settings->id)) {
            $settings = unserialize($settings->setting_value);

        } else {
            $settings = [
                'facebook' => "https://www.facebook.com/Adnanhyder123",
                'twitter' => "https://www.facebook.com/Adnanhyder123",
                'phone' => "+12345689456",
                'time' => "9AM to 5PM (Mon - Fri)",
                'admin_email' => "madiathemes@gmail.com",
                'copyrights' => "Copyright 2019 Maida. All Rights Reserved.",
                'title' => "helpyea",
                'logo' => "logo.png",
                'favicon' => "fav.png",
            ];

        }
        return $settings;
    }

    public function footer_menu()
    {
        $page = Faqs::OrderBy("id", "desc")->where('identity', "=", "page")->get();
        $data = [];
        foreach ($page as $single) {
            $data[] = [
                "id" => $single->id,
                "title" => $single->title,
                "slug" => $single->slug,
            ];
        }
      if(empty($data)){
          $data[] = [
              "title" => "Privacy",
              "slug" => "",
          ];
          $data[] = [
              "title" => "Terms & Conditions",
              "slug" => "",
          ];
      }
           return json_encode($data);
    }

    public function page($slug)
    {

        $page = Faqs::OrderBy("id", "desc")->where('slug', "=", $slug)->first();
        return view('page')->with("settings", json_encode($this->returnSettings()))->with('page', $page)->with('menu', $this->footer_menu());
    }


}
