<?php

namespace App\Http\Controllers;

use App\Mail\EmailSend;
use App\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    //
    public function send(Request $request)
    {
        $admin_email = $this->returnSettings();
        $admin_email = $admin_email['admin_email'];

        $obj = new \stdClass();
        $obj->name = $request->name;
        $obj->lastname = $request->lastname;
        $obj->email = $request->email;
        $obj->message = $request->message;
        $obj->footerlogo = asset('img').'/logo.png';

        Mail::to($admin_email)->send(new EmailSend($obj));
        return back()->with('success', 'Message Sent Successfully');
    }


    public function returnSettings(){
        $settings = Setting::orderBy('id', 'desc')->where("setting_name", "=", "maida_site_settings")->first();

        if (isset($settings->id)) {
            $settings = unserialize($settings->setting_value);

        } else {
            $settings = [
                'facebook' => "https://www.facebook.com/Adnanhyder123",
                'twitter' => "https://www.facebook.com/Adnanhyder123",
                'phone' => "+12345689456",
                'time' => "9AM to 5PM (Mon - Fri)",
                'admin_email' => "madiathemes@gmail.com",
                'copyrights' => "Copyright 2019 Maida. All Rights Reserved.",
                'title' => "helpyea",
                'logo' => "logo.png",
                'favicon' => "fav.png",
            ];

        }
        return $settings;
    }
}
