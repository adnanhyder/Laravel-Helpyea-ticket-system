<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class InactiveUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        if (Auth::user()->status == "inactive") {
            Auth::logout();
            return redirect()->route('login')->withErrors(['', 'Your Account is Inactive 
            Contact Administration through Contact page ']);

        } else {
            return $next($request);
        }


        return $next($request);
    }
}
