<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class RoleView
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        if (Auth::user()->roles == "admin") {
            return $next($request);
        }elseif(Auth::user()->roles == "manager"){
            return redirect('tickets');
        }elseif(Auth::user()->roles == "normal"){
            return redirect('404');
        }
    }
}
