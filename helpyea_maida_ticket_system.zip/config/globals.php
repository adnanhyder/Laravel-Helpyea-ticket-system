<?php
return [
  'form_email' => env('MAIL_FROM')
];