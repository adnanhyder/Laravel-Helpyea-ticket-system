<?php

use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/contact', 'ContactController@index')->name('contact');
Route::get('/faq', 'ContactController@faq')->name('faq');
Route::get('/index', 'ContactController@welcome')->name('index');
Route::get('/', 'ContactController@welcome');
Route::post('/mail/send', 'MailController@send');




Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/ticket/{id}', 'HomeController@ticket');
Route::get('/submit', 'HomeController@submitTicket')->name('submit');
Route::get('/profile', 'HomeController@profile')->name('profile');
Route::post('/addticket', 'DataUserController@addTicket');
Route::post('/updateprofile', 'DataUserController@storeProfile');

/*admin routes*/
Route::get('/admin', 'HomeController@admin')->name('admin')->middleware('admin');
Route::get('/users', 'HomeController@users')->name('users')->middleware('admin');
Route::get('/adduser', 'HomeController@addUser')->name('adduser')->middleware('admin');
Route::post('/submituser', 'DataUserController@store')->middleware('admin');
Route::get('/deletuser/{id}', 'DataUserController@destroy')->middleware('admin');
Route::get('/adduser/{id}', 'HomeController@addUser')->middleware('admin');

Route::get('/sitesettings', 'HomeController@siteSettings')->name('sitesetting')->middleware('admin');
Route::post('/submitsettings', 'DataUserController@siteSettings')->middleware('admin');


Route::get('/faqs', 'HomeController@faqs')->name('faqs')->middleware('admin');
Route::get('/faq/{id}', 'HomeController@showSingleFaq')->middleware('admin');
Route::get('/deletefaq/{id}', 'DataUserController@destroyFaq')->middleware('admin');
Route::get('/addfaq', 'HomeController@addFaq')->name('addfaq')->middleware('admin');
Route::get('/faqs/{id}', 'HomeController@addFaq')->middleware('admin');
Route::post('/submitfaq', 'DataUserController@faqStore')->middleware('admin');
Route::get('/searchfaq', 'ContactController@searchFaq');




Route::get('/tickets', 'HomeController@showTickets')->name('tickets');
Route::get('/topen', 'HomeController@showTicketsOpen')->name('ticketsOpen');
Route::get('/tclose', 'HomeController@showTicketsClose')->name('ticketsClose');
Route::get('/tickets/{id}', 'HomeController@showSingleTicket');
Route::get('/deleteticket/{id}', 'DataUserController@deleteTicket')->middleware('admin');
Route::get('/closeticket/{id}', 'DataUserController@closeTicket');
Route::get('/reopenticket/{id}', 'DataUserController@reopenTicket');

Route::get('/department', 'HomeController@departments')->name('department')->middleware('admin');
Route::get('/adddepartment', 'HomeController@addDepartment')->name('adddepartment')->middleware('admin');
Route::post('/submitdepartment', 'DataUserController@departmentStore')->middleware('admin');
Route::get('/deletdepartment/{id}', 'DataUserController@destroyDepartment')->middleware('admin');
Route::get('/adddepartment/{id}', 'HomeController@addDepartment')->middleware('admin');

Route::post('/assignManger', 'DataUserController@assignManger')->middleware('admin');

/*Public routes*/

Route::get('/{slug}', 'ContactController@page');